import React, { useState, useEffect } from 'react';
import { SceneSettings, PresetName, MediaType, ExportSettings } from './types';
import { DEFAULT_SETTINGS, PRESETS } from './constants';
import SceneCanvas from './components/Three/SceneCanvas';
import Sidebar from './components/UI/Sidebar';
import DropZone from './components/UI/DropZone';
import Timeline from './components/UI/Timeline';
import InteractiveBackground from './components/UI/InteractiveBackground';
import ExportModal from './components/UI/ExportModal';
import { Box, Moon, Sun, AlertCircle } from 'lucide-react';

class ErrorBoundary extends React.Component<{children: React.ReactNode}, {hasError: boolean, error: Error | null}> {
  constructor(props: {children: React.ReactNode}) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error("Uncaught error:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="flex flex-col items-center justify-center h-full p-8 text-center bg-white dark:bg-neo-black text-neo-black dark:text-white">
            <div className="bg-red-500 text-white p-4 rounded-full mb-4">
                <AlertCircle size={48} />
            </div>
            <h2 className="text-2xl font-black uppercase italic mb-2">Render Error</h2>
            <p className="bg-red-50 dark:bg-red-900/30 border-2 border-red-200 dark:border-red-800 p-4 font-mono text-xs max-w-lg overflow-auto mb-6 text-left">
                {this.state.error?.message}
            </p>
            <button 
                onClick={() => {
                    this.setState({ hasError: false, error: null });
                    window.location.reload();
                }}
                className="px-6 py-2 bg-neo-black dark:bg-white text-white dark:text-neo-black font-bold uppercase hover:opacity-80 transition-opacity"
            >
                Reload App
            </button>
        </div>
      );
    }

    return this.props.children;
  }
}

const App: React.FC = () => {
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [mediaUrl, setMediaUrl] = useState<string | null>(null);
  const [mediaType, setMediaType] = useState<MediaType>('video');
  const [settings, setSettings] = useState<SceneSettings>(DEFAULT_SETTINGS);
  const [isDarkMode, setIsDarkMode] = useState(false);
  
  // Global Time State
  const [currentTime, setCurrentTime] = useState(0); // Normalized 0 to 1
  const [isPlaying, setIsPlaying] = useState(false);
  const [duration, setDuration] = useState(10); // Default duration for images (seconds)
  
  // Export State
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [exportSettings, setExportSettings] = useState<ExportSettings>({
      resolution: '1080p',
      fps: 30,
      format: 'mp4'
  });

  // Toggle Dark Mode Class
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  // Animation Loop for Playback
  useEffect(() => {
    let animationFrame: number;
    let lastTime = performance.now();

    const loop = (now: number) => {
      if (isPlaying) {
        const delta = (now - lastTime) / 1000; // seconds
        setCurrentTime(prev => {
          const next = prev + (delta / duration);
          return next >= 1 ? 0 : next;
        });
      }
      lastTime = now;
      animationFrame = requestAnimationFrame(loop);
    };

    if (isPlaying) {
      animationFrame = requestAnimationFrame(loop);
    }

    return () => cancelAnimationFrame(animationFrame);
  }, [isPlaying, duration]);

  const handleFileSelect = (file: File) => {
    setVideoFile(file);
    const url = URL.createObjectURL(file);
    setMediaUrl(url);
    if (file.type.startsWith('image/')) {
        setMediaType('image');
        setDuration(5); // Default 5s for images
    } else {
        setMediaType('video');
        // Video duration will be set by the VideoHandler in SceneCanvas via callback if we added one, 
        // but for now we'll approximate or let the user set duration for the timeline if it's purely animation based.
        // Ideally, we get duration from the loaded metadata.
        const video = document.createElement('video');
        video.src = url;
        video.onloadedmetadata = () => {
           setDuration(video.duration);
        }
    }
  };

  const updateSettings = (newSettings: Partial<SceneSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  };

  const handleKeyframeUpdate = (id: string, newTimestamp: number) => {
    const updatedKeyframes = settings.zoom.keyframes.map(kf => 
      kf.id === id ? { ...kf, timestamp: newTimestamp } : kf
    ).sort((a, b) => a.timestamp - b.timestamp);
    
    updateSettings({ zoom: { ...settings.zoom, keyframes: updatedKeyframes } });
  };

  const applyPreset = (presetId: PresetName) => {
    const preset = PRESETS.find(p => p.id === presetId);
    if (preset) {
      updateSettings(preset.settings);
    } else {
      setSettings(DEFAULT_SETTINGS);
    }
  };

  const startExport = () => {
    if (!mediaUrl) return;

    setIsExportModalOpen(false);

    // 1. Reset State
    setIsPlaying(false);
    setCurrentTime(0);

    // 2. Start Recording Sequence
    // We give a small buffer for the reset to propagate to 3D scene and for resizer to kick in
    setTimeout(() => {
        setIsExporting(true);
        setIsPlaying(true);

        // 3. Stop after duration
        setTimeout(() => {
            setIsPlaying(false);
            setIsExporting(false);
            setCurrentTime(0);
        }, duration * 1000 + 500); // Add small buffer for safety
    }, 500);
  };

  return (
    <div className="flex flex-col h-screen bg-pastel-yellow dark:bg-neo-black text-neo-black dark:text-white font-sans overflow-hidden transition-colors duration-300">
      
      <ExportModal 
        isOpen={isExportModalOpen} 
        onClose={() => setIsExportModalOpen(false)} 
        onExport={startExport}
        settings={exportSettings}
        setSettings={setExportSettings}
      />

      {/* Top Bar */}
      <header className="h-16 border-b-2 border-neo-black dark:border-white bg-pastel-yellow dark:bg-neo-darkgray flex items-center px-6 justify-between z-30 relative transition-colors duration-300">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-pastel-pink dark:bg-neo-gray border-2 border-neo-black dark:border-white shadow-neo-sm dark:shadow-neo-sm-white flex items-center justify-center transition-all">
             <Box size={20} className="text-neo-black dark:text-white" />
          </div>
          <h1 className="text-2xl font-black tracking-tight italic">TiltStudio</h1>
          <span className="px-2 py-0.5 text-xs font-bold bg-pastel-blue text-neo-black border-2 border-neo-black dark:border-white shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] dark:shadow-[2px_2px_0px_0px_rgba(255,255,255,1)]">BETA</span>
        </div>
        <div className="flex items-center gap-4">
             <button 
               onClick={() => setIsDarkMode(!isDarkMode)}
               className="p-2 border-2 border-neo-black dark:border-white bg-white dark:bg-neo-gray shadow-neo-sm dark:shadow-neo-sm-white hover:translate-y-[1px] hover:shadow-none transition-all"
             >
               {isDarkMode ? <Sun size={18} /> : <Moon size={18} />}
             </button>

             <button className="px-4 py-2 text-sm font-bold border-2 border-transparent hover:underline transition-colors hidden sm:block">Docs</button>
             <button 
                onClick={() => setIsExportModalOpen(true)}
                disabled={!mediaUrl || isExporting}
                className={`
                    px-6 py-2 text-sm font-bold bg-neo-white dark:bg-neo-black text-neo-black dark:text-white border-2 border-neo-black dark:border-white shadow-neo dark:shadow-neo-white transition-all 
                    ${isExporting ? 'opacity-50 cursor-not-allowed' : 'hover:translate-x-[2px] hover:translate-y-[2px] hover:shadow-neo-sm dark:hover:shadow-neo-sm-white active:translate-x-[4px] active:translate-y-[4px] active:shadow-none'}
                `}
             >
                {isExporting ? 'Recording...' : 'Export'}
             </button>
        </div>
      </header>

      {/* Main Workspace */}
      <div className="flex-1 flex overflow-hidden relative">
        
        {/* 3D Viewport / Drop Area */}
        <div className="flex-1 relative bg-white dark:bg-neo-black border-r-2 border-neo-black dark:border-white transition-colors duration-300">
           {!mediaUrl ? (
             <div className="absolute inset-0 flex items-center justify-center p-20 z-10 overflow-hidden">
                <InteractiveBackground isDarkMode={isDarkMode} />
                <div className="w-full max-w-xl aspect-video relative z-20">
                  <DropZone onFileSelect={handleFileSelect} />
                </div>
             </div>
           ) : (
             <ErrorBoundary>
                <SceneCanvas 
                    key={mediaUrl} 
                    mediaSrc={mediaUrl} 
                    mediaType={mediaType}
                    settings={settings} 
                    updateSettings={updateSettings}
                    currentTime={currentTime}
                    isPlaying={isPlaying}
                    isExporting={isExporting}
                    duration={duration}
                    exportSettings={exportSettings}
                />
             </ErrorBoundary>
           )}
        </div>

        {/* Right Sidebar */}
        <div className="relative z-20 h-full">
          <Sidebar 
            settings={settings} 
            updateSettings={updateSettings} 
            applyPreset={applyPreset}
            currentTime={currentTime}
          />
        </div>
      </div>

      {/* Bottom Timeline */}
      {mediaUrl && (
          <div className="z-20 relative">
            <Timeline 
                currentTime={currentTime} 
                duration={duration} 
                isPlaying={isPlaying} 
                onPlayPause={() => setIsPlaying(!isPlaying)}
                onSeek={(time) => setCurrentTime(time)}
                keyframes={settings.zoom.keyframes}
                onKeyframeUpdate={handleKeyframeUpdate}
            />
          </div>
      )}
    </div>
  );
};

export default App;