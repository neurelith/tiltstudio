import React, { Suspense, useEffect, useRef, useState, useMemo, useLayoutEffect } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { 
  OrbitControls, 
  Environment, 
  ContactShadows, 
  RoundedBox, 
  Float,
  Stars,
  Sparkles,
  Grid,
  Sphere,
  Text,
} from '@react-three/drei';
import * as THREE from 'three';
import { EXRLoader } from 'three-stdlib';
import { SceneSettings, BackgroundType, MediaType, Keyframe, ExportSettings } from '../../types';

declare module 'react' {
  namespace JSX {
    interface IntrinsicElements {
      group: any;
      mesh: any;
      pointLight: any;
      meshStandardMaterial: any;
      planeGeometry: any;
      meshBasicMaterial: any;
      ambientLight: any;
      spotLight: any;
      color: any;
      ringGeometry: any;
      directionalLight: any;
      sphereGeometry: any;
      shapeGeometry: any;
    }
  }
}

interface SceneCanvasProps {
  mediaSrc: string;
  mediaType: MediaType;
  settings: SceneSettings;
  updateSettings: (s: Partial<SceneSettings>) => void;
  currentTime: number; // 0 to 1
  duration: number; // Total duration in seconds
  isPlaying: boolean;
  isExporting?: boolean;
  exportSettings: ExportSettings;
}

// --------------------------------------------------------
// Loader Component (Static Mesh to avoid context hooks issues)
// --------------------------------------------------------
const Loader = () => {
  // Removed hooks and Drei components to ensures this is purely passive 
  // and won't trigger context errors during mounting/suspense
  return (
    <group>
        <mesh rotation={[Math.PI / 4, Math.PI / 4, 0]}>
            <torusGeometry args={[1, 0.1, 16, 32]} />
            <meshStandardMaterial color="#FDE047" emissive="#FDE047" emissiveIntensity={0.5} />
        </mesh>
    </group>
  );
};

// --------------------------------------------------------
// Recorder Component
// --------------------------------------------------------
const Recorder = ({ isExporting, settings }: { isExporting: boolean; settings: ExportSettings }) => {
  const { gl, size } = useThree();
  const mediaRecorder = useRef<MediaRecorder | null>(null);
  const chunks = useRef<Blob[]>([]);
  const originalSize = useRef<{width: number, height: number} | null>(null);

  useEffect(() => {
    if (isExporting) {
      chunks.current = [];
      const canvas = gl.domElement;
      
      // Store original size
      if (!originalSize.current) {
        originalSize.current = { width: size.width, height: size.height };
      }

      // Set Resolution
      let targetWidth = 1920;
      let targetHeight = 1080;
      
      if (settings.resolution === '720p') {
          targetWidth = 1280;
          targetHeight = 720;
      } else if (settings.resolution === '4k') {
          targetWidth = 3840;
          targetHeight = 2160;
      }

      gl.setSize(targetWidth, targetHeight, false);
      
      // Determine Mime Type
      let mimeType = 'video/webm';
      if (settings.format === 'mp4' && MediaRecorder.isTypeSupported('video/mp4')) {
        mimeType = 'video/mp4';
      } else if (MediaRecorder.isTypeSupported('video/webm;codecs=vp9')) {
        mimeType = 'video/webm;codecs=vp9';
      }

      const stream = canvas.captureStream(settings.fps);
      
      try {
        const recorder = new MediaRecorder(stream, { 
            mimeType, 
            videoBitsPerSecond: settings.resolution === '4k' ? 50000000 : 25000000 // High bitrate
        });
        mediaRecorder.current = recorder;
        
        recorder.ondataavailable = (e) => {
          if (e.data.size > 0) chunks.current.push(e.data);
        };
        
        recorder.onstop = () => {
          // Restore Size
          if (originalSize.current) {
             gl.setSize(originalSize.current.width, originalSize.current.height, false);
          }

          const blob = new Blob(chunks.current, { type: mimeType });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `tilt-studio-${settings.resolution}.${settings.format}`; 
          a.click();
          URL.revokeObjectURL(url);
        };
        
        recorder.start();
      } catch (e) {
        console.error("Recorder error", e);
      }
    } else {
      if (mediaRecorder.current && mediaRecorder.current.state !== 'inactive') {
        mediaRecorder.current.stop();
      }
    }
  }, [isExporting, gl, size, settings.resolution, settings.format, settings.fps]);

  return null;
}

// --------------------------------------------------------
// Helpers
// --------------------------------------------------------
const easeInOutCubic = (t: number): number => t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
const easeOutElastic = (x: number): number => {
  const c4 = (2 * Math.PI) / 3;
  return x === 0 ? 0 : x === 1 ? 1 : Math.pow(2, -10 * x) * Math.sin((x * 10 - 0.75) * c4) + 1;
};
const easeOutBounce = (x: number): number => {
    const n1 = 7.5625;
    const d1 = 2.75;
    if (x < 1 / d1) {
        return n1 * x * x;
    } else if (x < 2 / d1) {
        return n1 * (x -= 1.5 / d1) * x + 0.75;
    } else if (x < 2.5 / d1) {
        return n1 * (x -= 2.25 / d1) * x + 0.9375;
    } else {
        return n1 * (x -= 2.625 / d1) * x + 0.984375;
    }
};

const getInterpolationT = (currentTime: number, keyframes: Keyframe[], settings: SceneSettings, totalDuration: number) => {
    if (keyframes.length === 0) return null;
    
    // Calculate progress based on Zoom Duration if set, otherwise use full video duration
    const speed = (settings.zoom.zoomDuration && settings.zoom.zoomDuration > 0) ? settings.zoom.zoomDuration : totalDuration;
    const currentSeconds = currentTime * totalDuration;
    
    // Zoom Types Overrides
    if (settings.zoom.type === 'in-only') {
        let t = Math.min(1, currentSeconds / speed);
        if (settings.zoom.interpolation === 'ease') t = easeInOutCubic(t);
        if (settings.zoom.interpolation === 'bounce') t = easeOutBounce(t);
        if (settings.zoom.interpolation === 'elastic') t = easeOutElastic(t);

        return { t: t, startKF: { ...keyframes[0], intensity: 1, target: {x:0.5, y:0.5} }, endKF: { ...keyframes[0], intensity: 2.5 } };
    }
    if (settings.zoom.type === 'out-only') {
        let t = Math.min(1, currentSeconds / speed);
        if (settings.zoom.interpolation === 'ease') t = easeInOutCubic(t);
        if (settings.zoom.interpolation === 'bounce') t = easeOutBounce(t);
        if (settings.zoom.interpolation === 'elastic') t = easeOutElastic(t);

        return { t: t, startKF: { ...keyframes[0], intensity: 2.5, target: {x:0.5, y:0.5} }, endKF: { ...keyframes[0], intensity: 1 } };
    }
    if (settings.zoom.type === 'constant') {
        return { t: currentTime, startKF: { ...keyframes[0], intensity: 1.5, target: {x:0.5, y:0.5} }, endKF: { ...keyframes[0], intensity: 1.8 } };
    }
    if (settings.zoom.type === 'in-out') {
        const cycleProgress = (currentSeconds % speed) / speed; 
        let t = Math.min(1, currentSeconds / speed);
        let subT = 0;
        if (t < 0.5) subT = t * 2;
        else subT = 2 - (t * 2);

        if (settings.zoom.interpolation === 'ease') subT = easeInOutCubic(subT);
        
        return { t: subT, startKF: { ...keyframes[0], intensity: 1, target: {x:0.5, y:0.5} }, endKF: { ...keyframes[0], intensity: 2.0 } };
    }

    const sorted = [...keyframes].sort((a, b) => a.timestamp - b.timestamp);

    if (currentTime < sorted[0].timestamp) {
        const startKF: Keyframe = {
            id: 'virtual-start',
            timestamp: 0,
            target: { x: 0.5, y: 0.5 }, 
            intensity: 1, 
            rotation: settings.rotation, 
            extrusion: settings.extrusion 
        };
        const endKF = sorted[0];
        const duration = endKF.timestamp;
        let t = 0;
        if (duration > 0.0001) t = currentTime / duration;
        
        let easedT = t;
        if (settings.zoom.interpolation === 'ease') easedT = easeInOutCubic(t);
        if (settings.zoom.interpolation === 'bounce') easedT = easeOutBounce(t);
        if (settings.zoom.interpolation === 'elastic') easedT = easeOutElastic(t);

        return { t: easedT, startKF, endKF };
    }

    if (currentTime >= sorted[sorted.length - 1].timestamp) {
        return { t: 1, startKF: sorted[sorted.length - 1], endKF: sorted[sorted.length - 1] };
    }

    let startKF = sorted[0];
    let endKF = sorted[sorted.length - 1];

    for (let i = 0; i < sorted.length - 1; i++) {
        if (currentTime >= sorted[i].timestamp && currentTime <= sorted[i+1].timestamp) {
            startKF = sorted[i];
            endKF = sorted[i+1];
            break;
        }
    }
    
    const duration = endKF.timestamp - startKF.timestamp;
    let t = 0;
    if (duration > 0.0001) {
        t = (currentTime - startKF.timestamp) / duration;
    }
    
    let easedT = t;
    if (settings.zoom.interpolation === 'ease') easedT = easeInOutCubic(t);
    if (settings.zoom.interpolation === 'bounce') easedT = easeOutBounce(t);
    if (settings.zoom.interpolation === 'elastic') easedT = easeOutElastic(t);
    
    return { t: easedT, startKF, endKF };
}


// --------------------------------------------------------
// RoundedScreen Component
// --------------------------------------------------------
const RoundedScreen = ({ width, height, radius, map, handlePointerDown, picking, settings, isDesktop }: any) => {
  const shape = useMemo(() => {
    const s = new THREE.Shape();
    const w = width;
    const h = height;
    const x = -w / 2;
    const y = -h / 2;
    const r = Math.min(radius, w/2, h/2);

    s.moveTo(x + r, y + h);
    s.lineTo(x + w - r, y + h);
    s.quadraticCurveTo(x + w, y + h, x + w, y + h - r);
    s.lineTo(x + w, y + r);
    s.quadraticCurveTo(x + w, y, x + w - r, y);
    s.lineTo(x + r, y);
    s.quadraticCurveTo(x, y, x, y + r);
    s.lineTo(x, y + h - r);
    s.quadraticCurveTo(x, y + h, x + r, y + h);
    return s;
  }, [width, height, radius]);

  const geomRef = useRef<THREE.ShapeGeometry>(null);

  useLayoutEffect(() => {
    if (geomRef.current) {
        const pos = geomRef.current.attributes.position;
        const uv = geomRef.current.attributes.uv;
        for(let i=0; i<pos.count; i++){
            const x = pos.getX(i);
            const y = pos.getY(i);
            const u = (x + width/2) / width;
            const v = (y + height/2) / height;
            uv.setXY(i, u, v);
        }
        uv.needsUpdate = true;
    }
  }, [shape, width, height]);

  return (
    <mesh 
        position={[0, isDesktop ? 0.1 : 0, settings.extrusion / 2 + 0.002]} 
        onPointerDown={handlePointerDown}
        onPointerOver={() => document.body.style.cursor = picking ? 'crosshair' : 'default'}
        onPointerOut={() => document.body.style.cursor = 'default'}
    >
        <shapeGeometry ref={geomRef} args={[shape]} />
        <meshBasicMaterial 
            map={map} 
            toneMapped={false} 
            transparent={true} 
            opacity={settings.videoOpacity} 
        />
    </mesh>
  )
}

// --------------------------------------------------------
// Animated Text Component
// --------------------------------------------------------
const AnimatedText = ({ layer, width, height, activeExtrusion, currentTime, totalDuration }: any) => {
    const startTime = layer.animation.startDelay; 
    const duration = layer.animation.duration;
    const currentSeconds = currentTime * totalDuration;
    
    let opacity = layer.opacity;
    let posX = layer.position.x * width;
    let posY = layer.position.y * height;
    let textContent = layer.text;

    if (layer.animation.type !== 'none') {
        const animProgress = Math.max(0, Math.min(1, (currentSeconds - startTime) / duration));
        
        if (currentSeconds < startTime) {
            if (layer.animation.type === 'fade-in' || layer.animation.type === 'slide-in' || layer.animation.type === 'typewriter') {
                opacity = 0;
            }
        } else {
            if (layer.animation.type === 'fade-in') {
                opacity = layer.opacity * animProgress;
            } else if (layer.animation.type === 'slide-in') {
                opacity = layer.opacity * animProgress; 
                posY = (layer.position.y * height) - (1 - animProgress) * 0.5;
            } else if (layer.animation.type === 'typewriter') {
                opacity = layer.opacity;
                const charCount = Math.floor(animProgress * layer.text.length);
                textContent = layer.text.substring(0, charCount);
            }
        }
    }

    return (
        <Text
            position={[posX, posY, activeExtrusion + 0.1]}
            fontSize={layer.fontSize}
            color={layer.color}
            fillOpacity={opacity}
            font="https://fonts.gstatic.com/s/inter/v12/UcCO3FwrK3iLTeHuS_fvQtMwCp50KnMw2boKoduKmMEVuLyfAZ9hjp-Ek-_EeA.woff"
            anchorX="center"
            anchorY="middle"
        >
            {textContent}
        </Text>
    );
};


// --------------------------------------------------------
// Reusable Device Frame
// --------------------------------------------------------
const DeviceFrame = ({ 
    texture, 
    aspectRatio, 
    settings, 
    onPick,
    activeKeyframe,
    currentTime,
    duration
}: { 
    texture: THREE.Texture; 
    aspectRatio: number; 
    settings: SceneSettings;
    onPick: (uv: THREE.Vector2) => void;
    activeKeyframe: Keyframe | null;
    currentTime: number;
    duration: number;
}) => {
    const meshRef = useRef<THREE.Group>(null);
    const width = 4;
    const height = width / aspectRatio;

    const isDesktop = settings.background === 'desktop-screen';

    useFrame((state, delta) => {
        if (meshRef.current) {
            let rotX = settings.rotation.x;
            let rotY = settings.rotation.y;
            let rotZ = settings.rotation.z;
            let currentScale = settings.scale;

            if (settings.zoom.active && settings.zoom.keyframes.length > 0) {
                 const interp = getInterpolationT(currentTime, settings.zoom.keyframes, settings, duration);
                 if (interp) {
                    const { t, startKF, endKF } = interp;
                    if (startKF.rotation && endKF.rotation) {
                        rotX = THREE.MathUtils.lerp(startKF.rotation.x, endKF.rotation.x, t);
                        rotY = THREE.MathUtils.lerp(startKF.rotation.y, endKF.rotation.y, t);
                        rotZ = THREE.MathUtils.lerp(startKF.rotation.z, endKF.rotation.z, t);
                    }
                 }
            }

            meshRef.current.rotation.x = THREE.MathUtils.lerp(meshRef.current.rotation.x, rotX, 0.15);
            meshRef.current.rotation.y = THREE.MathUtils.lerp(meshRef.current.rotation.y, rotY, 0.15);
            meshRef.current.rotation.z = THREE.MathUtils.lerp(meshRef.current.rotation.z, rotZ, 0.15);

            const interpolatedScale = THREE.MathUtils.lerp(meshRef.current.scale.x, currentScale, 0.15);
            meshRef.current.scale.set(interpolatedScale, interpolatedScale, interpolatedScale);
        }
    });

    const handlePointerDown = (e: any) => {
        if (settings.zoom.picking) {
            e.stopPropagation();
            onPick(e.uv);
        }
    };

    let activeExtrusion = settings.extrusion;
    if (settings.zoom.active && settings.zoom.keyframes.length > 0) {
         const interp = getInterpolationT(currentTime, settings.zoom.keyframes, settings, duration);
         if (interp) {
             const { t, startKF, endKF } = interp;
             if (startKF.extrusion !== undefined && endKF.extrusion !== undefined) {
                activeExtrusion = THREE.MathUtils.lerp(startKF.extrusion, endKF.extrusion, t);
             }
         }
    }

    return (
        <group>
             <Float 
                speed={settings.motionBlur ? 3 : 0} 
                rotationIntensity={settings.motionBlur ? 0.2 : 0} 
                floatIntensity={settings.motionBlur ? 0.4 : 0}
            >
                <group ref={meshRef}>
                     {/* Text Layers */}
                     {settings.textLayers.map((layer) => (
                         <AnimatedText 
                            key={layer.id} 
                            layer={layer} 
                            width={width} 
                            height={height} 
                            activeExtrusion={activeExtrusion}
                            currentTime={currentTime}
                            totalDuration={duration}
                        />
                     ))}

                    {settings.zoom.picking && settings.zoom.keyframes.map((kf, i) => (
                        <group key={kf.id} position={[(kf.target.x - 0.5) * width, (kf.target.y - 0.5) * height, activeExtrusion / 2 + 0.02]}>
                            <mesh>
                                <ringGeometry args={[0.02, 0.04, 16]} />
                                <meshBasicMaterial color="#EF4444" opacity={0.6} transparent side={THREE.DoubleSide} />
                            </mesh>
                        </group>
                    ))}

                    {settings.zoom.background && (
                         <mesh position={[0, isDesktop ? 0.1 : 0, -activeExtrusion/2 - 0.05]}>
                             <planeGeometry args={[width + 0.5, height + 0.5]} />
                             <meshBasicMaterial color="#FFDD55" /> 
                         </mesh>
                    )}

                     {settings.zoom.dropShadow && (
                        <RoundedBox
                            args={[width + (isDesktop ? 0.2 : 0), height + (isDesktop ? 0.4 : 0), 0.01]}
                            radius={settings.borderRadius}
                            smoothness={4}
                            position={[0, -0.2, -activeExtrusion/2 - 0.2]}
                        >
                            <meshBasicMaterial color="#000000" transparent opacity={0.4} />
                        </RoundedBox>
                     )}

                    {settings.glow && (
                        <pointLight position={[0, 0, -2]} intensity={3} color="#F9A8D4" distance={10} />
                    )}

                    <RoundedBox 
                        args={[width + (isDesktop ? 0.2 : 0), height + (isDesktop ? 0.4 : 0), activeExtrusion]} 
                        radius={settings.borderRadius} 
                        smoothness={4}
                        position={[0, isDesktop ? 0.1 : 0, 0]}
                    >
                        <meshStandardMaterial 
                            color={isDesktop ? "#1A1A1A" : "#121212"} 
                            roughness={isDesktop ? 0.3 : 0.4} 
                            metalness={isDesktop ? 0.8 : 0.6} 
                            transparent={true}
                            opacity={settings.videoOpacity}
                        />
                    </RoundedBox>

                    {isDesktop && (
                        <group position={[0, -height/2 - 0.8, -0.2]}>
                            <RoundedBox args={[0.8, 1.8, 0.2]} radius={0.05} position={[0, 0.6, 0]}>
                                <meshStandardMaterial color="#333" roughness={0.5} metalness={0.7} />
                            </RoundedBox>
                            <RoundedBox args={[2, 0.1, 1.5]} radius={0.1} position={[0, -0.3, 0.3]}>
                                <meshStandardMaterial color="#333" roughness={0.5} metalness={0.7} />
                            </RoundedBox>
                        </group>
                    )}

                    <RoundedScreen 
                        width={width - 0.1} 
                        height={height - 0.1} 
                        radius={Math.max(0, settings.borderRadius)} 
                        map={texture} 
                        handlePointerDown={handlePointerDown} 
                        picking={settings.zoom.picking}
                        settings={{...settings, extrusion: activeExtrusion}}
                        isDesktop={isDesktop}
                    />

                    <mesh position={[0, isDesktop ? 0.1 : 0, -(activeExtrusion / 2 + 0.001)]} rotation={[0, Math.PI, 0]}>
                        <planeGeometry args={[width - 0.1, height - 0.1]} />
                        <meshStandardMaterial color="#222" roughness={0.2} metalness={0.8} />
                    </mesh>
                </group>
            </Float>
        </group>
    )
}

// --------------------------------------------------------
// Media Handlers
// --------------------------------------------------------
const VideoHandler = ({ src, settings, onPick, setAspectRatio, currentTime, duration }: any) => {
    // Custom Video Texture Implementation to avoid drei's useVideoTexture mismatch
    const [video] = useState(() => {
        const vid = document.createElement('video');
        vid.src = src;
        vid.crossOrigin = 'Anonymous';
        vid.loop = true;
        vid.muted = true;
        vid.playsInline = true;
        vid.autoplay = true;
        return vid;
    });

    useEffect(() => {
        video.src = src;
        video.play();
    }, [src, video]);

    useEffect(() => {
        if (Number.isFinite(video.duration)) {
             const targetTime = currentTime * video.duration;
             if (Math.abs(video.currentTime - targetTime) > 0.2) {
                 video.currentTime = targetTime;
             }
        }
    }, [currentTime, video]);

    useEffect(() => {
        const handleResize = () => {
            if (video.videoWidth && video.videoHeight) {
                setAspectRatio(video.videoWidth / video.videoHeight);
            }
        };
        video.addEventListener('loadedmetadata', handleResize);
        return () => video.removeEventListener('loadedmetadata', handleResize);
    }, [video, setAspectRatio]);

    // Create texture manually
    const texture = useMemo(() => {
        const tex = new THREE.VideoTexture(video);
        tex.minFilter = THREE.LinearFilter;
        tex.magFilter = THREE.LinearFilter;
        tex.colorSpace = THREE.SRGBColorSpace;
        return tex;
    }, [video]);

    // Force update of texture
    useFrame(() => {
        if (texture) texture.needsUpdate = true;
    });
    
    const aspect = video.videoWidth ? video.videoWidth / video.videoHeight : 16/9;
    
    return <DeviceFrame texture={texture} aspectRatio={aspect} settings={settings} onPick={onPick} activeKeyframe={null} currentTime={currentTime} duration={duration} />;
}

const ImageHandler = ({ src, settings, onPick, setAspectRatio, currentTime, duration }: any) => {
    // Manual texture loading to bypass useLoader/Suspense and associated context issues
    const [texture, setTexture] = useState<THREE.Texture | null>(null);

    useEffect(() => {
        const loader = new THREE.TextureLoader();
        loader.load(src, (tex) => {
            tex.colorSpace = THREE.SRGBColorSpace;
            setTexture(tex);
            if (tex.image?.width) {
                 setAspectRatio(tex.image.width / tex.image.height);
            }
        });
        return () => {
            setTexture(null); 
        };
    }, [src, setAspectRatio]);

    if (!texture) return null; 

    const image = texture.image as HTMLImageElement;
    const aspect = image?.width ? image.width / image.height : 16/9;
    return <DeviceFrame texture={texture} aspectRatio={aspect} settings={settings} onPick={onPick} activeKeyframe={null} currentTime={currentTime} duration={duration} />;
}


// --------------------------------------------------------
// Environment System
// --------------------------------------------------------
const CustomEnv = ({ url, isExr }: { url: string, isExr: boolean }) => {
    // Manual loading for environment texture to avoid useLoader/Suspense
    const [texture, setTexture] = useState<THREE.Texture | null>(null);

    useEffect(() => {
        const loader = isExr ? new EXRLoader() : new THREE.TextureLoader();
        loader.load(url, (tex) => {
            tex.mapping = THREE.EquirectangularReflectionMapping;
            setTexture(tex as THREE.Texture);
        });
        return () => {
            setTexture(null);
        };
    }, [url, isExr]);

    if (!texture) return null;

    return (
        <Environment map={texture} background={true} />
    );
};

const BackgroundEnv = ({ type, customUrl, customBackgroundIsExr }: { type: BackgroundType, customUrl: string | null, customBackgroundIsExr: boolean }) => {
  if (type === 'transparent') return null;

  return (
    <>
      {type === 'studio' && (
        <>
            <Environment preset="city" />
            <color attach="background" args={['#F3F4F6']} />
            <Grid infiniteGrid fadeDistance={50} sectionColor="#000000" cellColor="#cccccc" position={[0, -5, 0]} />
            <ambientLight intensity={0.6} />
        </>
      )}
      {type === 'mesh' && (
        <>
            <Environment preset="night" />
            <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />
            <Sparkles count={50} scale={10} size={4} speed={0.4} opacity={0.5} color="#00F0FF" />
            <color attach="background" args={['#111']} />
            <ambientLight intensity={0.3} />
        </>
      )}
      {type === 'windows11' && (
        <>
            <Environment preset="dawn" blur={0.8} />
             <color attach="background" args={['#E3F2FD']} />
             <Sphere args={[15, 32, 32]} position={[-5, 5, -30]}>
                <meshBasicMaterial color="#93C5FD" transparent opacity={0.4} />
             </Sphere>
             <Sphere args={[20, 32, 32]} position={[10, -5, -40]}>
                <meshBasicMaterial color="#DBEAFE" transparent opacity={0.6} />
             </Sphere>
             <ambientLight intensity={0.9} />
             <spotLight position={[5, 10, 5]} intensity={0.5} castShadow />
        </>
      )}
      {type === 'real-world' && (
        <>
            <Environment preset="park" background /> 
            <ambientLight intensity={0.8} />
            <directionalLight position={[10, 10, 10]} intensity={1.5} castShadow />
        </>
      )}
      {type === 'desktop-screen' && (
        <>
            <Environment preset="apartment" />
            <color attach="background" args={['#202020']} />
            <ambientLight intensity={1.5} />
            <spotLight position={[0, 10, 5]} intensity={1} castShadow />
            <mesh position={[0, -5, 0]} rotation={[-Math.PI/2, 0, 0]}>
                <planeGeometry args={[50, 50]} />
                <meshStandardMaterial color="#1a1a1a" roughness={0.2} metalness={0.5} />
            </mesh>
        </>
      )}
      {type === 'custom' && customUrl && (
          <CustomEnv url={customUrl} isExr={customBackgroundIsExr} />
      )}
    </>
  );
};

// --------------------------------------------------------
// Smart Camera with Interpolation
// --------------------------------------------------------
const SmartCameraRig = ({ 
    settings, 
    aspectRatio, 
    currentTime,
    duration
}: { 
    settings: SceneSettings; 
    aspectRatio: number; 
    currentTime: number;
    duration: number;
}) => {
    const { camera } = useThree();
    const controlsRef = useRef<any>(null);
    const shakeTime = useRef(0);
    
    const width = 4;
    const height = width / aspectRatio;

    useFrame((state, delta) => {
        let shakeX = 0;
        let shakeY = 0;
        if (settings.zoom.active && settings.zoom.shake > 0) {
            shakeTime.current += delta * 10;
            const intensity = settings.zoom.shake * 0.05;
            shakeX = Math.sin(shakeTime.current) * intensity;
            shakeY = Math.cos(shakeTime.current * 1.5) * intensity;
        }

        if (settings.zoom.active) {
            if (controlsRef.current) controlsRef.current.enabled = false;

            let targetX = 0;
            let targetY = 0;
            let targetZoomIntensity = 1;

            const keyframes = settings.zoom.keyframes;

            if (keyframes.length > 0) {
                const interp = getInterpolationT(currentTime, keyframes, settings, duration);
                if (interp) {
                    const { t, startKF, endKF } = interp;

                    const startX = (startKF.target.x - 0.5) * width;
                    const startY = (startKF.target.y - 0.5) * height;
                    const endX = (endKF.target.x - 0.5) * width;
                    const endY = (endKF.target.y - 0.5) * height;

                    targetX = THREE.MathUtils.lerp(startX, endX, t);
                    targetY = THREE.MathUtils.lerp(startY, endY, t);
                    targetZoomIntensity = THREE.MathUtils.lerp(startKF.intensity, endKF.intensity, t);
                }
            }
            
            const targetDist = 8 / targetZoomIntensity;
            const targetPos = new THREE.Vector3(targetX, targetY, targetDist);
            
            targetPos.x += shakeX;
            targetPos.y += shakeY;

            camera.position.lerp(targetPos, 0.1); 
            
            if (controlsRef.current) {
                const currentTarget = controlsRef.current.target;
                const desiredTarget = new THREE.Vector3(targetX + shakeX, targetY + shakeY, 0);
                currentTarget.lerp(desiredTarget, 0.1);
                camera.lookAt(currentTarget);
            }

        } else {
            if (controlsRef.current) {
                controlsRef.current.enabled = true;
                controlsRef.current.target.lerp(new THREE.Vector3(0, 0, 0), 0.05);
            }
        }
    });

    return (
        <OrbitControls 
            ref={controlsRef}
            makeDefault 
            autoRotate={settings.orbitPreview && !settings.zoom.active}
            autoRotateSpeed={2}
            enablePan={false}
            minPolarAngle={Math.PI / 4}
            maxPolarAngle={Math.PI / 2}
        />
    );
}

// --------------------------------------------------------
// Scene Content (Logic inside Canvas)
// --------------------------------------------------------
const SceneContent: React.FC<SceneCanvasProps> = ({ mediaSrc, mediaType, settings, updateSettings, currentTime, isPlaying, duration, isExporting = false, exportSettings }) => {
  const [aspectRatio, setAspectRatio] = useState(16 / 9);

  const handlePick = (uv: THREE.Vector2) => {
      const lastKF = settings.zoom.keyframes.length > 0 
        ? settings.zoom.keyframes[settings.zoom.keyframes.length - 1] 
        : null;

      const newKeyframe: Keyframe = {
          id: Math.random().toString(36).substr(2, 9),
          timestamp: currentTime,
          target: { x: uv.x, y: uv.y },
          intensity: 2.5,
          rotation: lastKF ? { ...lastKF.rotation } : { ...settings.rotation },
          extrusion: lastKF ? lastKF.extrusion : settings.extrusion
      };

      const newKeyframes = [...settings.zoom.keyframes, newKeyframe].sort((a, b) => a.timestamp - b.timestamp);

      updateSettings({ 
          zoom: { 
              ...settings.zoom, 
              keyframes: newKeyframes,
              picking: false 
          } 
      });
  };

  const height = 4 / aspectRatio;
  const shadowY = Math.min(-2.5, -(height * settings.scale) / 2 - 0.2);

  return (
    <>
        <Recorder isExporting={isExporting} settings={exportSettings} />
        <BackgroundEnv type={settings.background} customUrl={settings.customBackground} customBackgroundIsExr={settings.customBackgroundIsExr} />
        
        <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} intensity={1} castShadow />
        <pointLight position={[-10, -10, -10]} intensity={settings.ambientLightIntensity} />
        
        {mediaType === 'video' ? (
                <VideoHandler 
                src={mediaSrc} 
                settings={settings} 
                onPick={handlePick} 
                setAspectRatio={setAspectRatio} 
                currentTime={currentTime}
                duration={duration}
            />
        ) : (
                <ImageHandler 
                src={mediaSrc} 
                settings={settings} 
                onPick={handlePick} 
                setAspectRatio={setAspectRatio} 
                currentTime={currentTime}
                duration={duration}
            />
        )}
        
        <SmartCameraRig settings={settings} aspectRatio={aspectRatio} currentTime={currentTime} duration={duration} />
        
        {settings.background !== 'transparent' && settings.background !== 'real-world' && !settings.zoom.dropShadow && (
            <ContactShadows position={[0, shadowY, 0]} opacity={0.4} scale={20} blur={2} far={4.5} />
        )}
    </>
  );
};

// --------------------------------------------------------
// Main Canvas Component (Wrapper)
// --------------------------------------------------------
const SceneCanvas: React.FC<SceneCanvasProps> = (props) => {
  return (
    <div className="w-full h-full relative bg-transparent group">
        {props.settings.zoom.picking && (
            <div className="absolute top-4 left-1/2 -translate-x-1/2 z-50 bg-red-500 text-white px-4 py-2 font-bold uppercase tracking-wider text-sm shadow-neo border-2 border-white animate-pulse pointer-events-none">
                Click media to add Keyframe at {(props.currentTime * 100).toFixed(0)}%
            </div>
        )}

        {props.settings.background === 'studio' && <div className="absolute inset-0 bg-gray-100 -z-10" />}
        {props.settings.background === 'mesh' && <div className="absolute inset-0 bg-black -z-10" />}

        <Canvas 
            shadows 
            camera={{ position: [0, 0, 8], fov: 45 }}
            gl={{ preserveDrawingBuffer: true, alpha: props.settings.background === 'transparent' }}
            dpr={[1, 2]} 
        >
            <Suspense fallback={<Loader />}>
                <SceneContent {...props} />
            </Suspense>
        </Canvas>
    </div>
  );
};

export default SceneCanvas;