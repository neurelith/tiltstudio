
import React from 'react';
import { ExportSettings } from '../../types';
import { X, Download, Film } from 'lucide-react';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onExport: () => void;
  settings: ExportSettings;
  setSettings: (s: ExportSettings) => void;
}

const ExportModal: React.FC<ExportModalProps> = ({ isOpen, onClose, onExport, settings, setSettings }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-neo-black/80 backdrop-blur-sm">
      <div className="w-96 bg-white dark:bg-neo-gray border-4 border-neo-black dark:border-white shadow-neo-lg p-6 relative">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 text-neo-black dark:text-white hover:opacity-70"
        >
          <X size={24} />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="bg-pastel-green p-3 border-2 border-neo-black shadow-neo-sm">
            <Film size={24} className="text-neo-black" />
          </div>
          <h2 className="text-2xl font-black uppercase italic text-neo-black dark:text-white">Export Video</h2>
        </div>

        <div className="space-y-6">
          {/* Resolution */}
          <div>
            <label className="block text-xs font-bold uppercase mb-2 text-neo-black dark:text-white">Resolution</label>
            <div className="grid grid-cols-3 gap-2">
              {(['720p', '1080p', '4k'] as const).map(res => (
                <button
                  key={res}
                  onClick={() => setSettings({ ...settings, resolution: res })}
                  className={`py-2 text-sm font-bold border-2 ${settings.resolution === res ? 'bg-neo-black dark:bg-white text-white dark:text-neo-black border-neo-black dark:border-white' : 'border-gray-300 text-gray-500'}`}
                >
                  {res}
                </button>
              ))}
            </div>
          </div>

          {/* FPS */}
          <div>
            <label className="block text-xs font-bold uppercase mb-2 text-neo-black dark:text-white">Frame Rate</label>
            <div className="grid grid-cols-2 gap-2">
              {(['30', '60'] as const).map(fps => (
                <button
                  key={fps}
                  onClick={() => setSettings({ ...settings, fps: parseInt(fps) as 30 | 60 })}
                  className={`py-2 text-sm font-bold border-2 ${settings.fps === parseInt(fps) ? 'bg-neo-black dark:bg-white text-white dark:text-neo-black border-neo-black dark:border-white' : 'border-gray-300 text-gray-500'}`}
                >
                  {fps} FPS
                </button>
              ))}
            </div>
          </div>

          {/* Format */}
          <div>
            <label className="block text-xs font-bold uppercase mb-2 text-neo-black dark:text-white">Format</label>
            <div className="grid grid-cols-2 gap-2">
              {(['webm', 'mp4'] as const).map(fmt => (
                <button
                  key={fmt}
                  onClick={() => setSettings({ ...settings, format: fmt })}
                  className={`py-2 text-sm font-bold border-2 uppercase ${settings.format === fmt ? 'bg-neo-black dark:bg-white text-white dark:text-neo-black border-neo-black dark:border-white' : 'border-gray-300 text-gray-500'}`}
                >
                  {fmt}
                </button>
              ))}
            </div>
          </div>
        </div>

        <button
          onClick={onExport}
          className="w-full mt-8 py-3 bg-pastel-pink border-2 border-neo-black shadow-neo hover:translate-x-[2px] hover:translate-y-[2px] hover:shadow-neo-sm transition-all flex items-center justify-center gap-2 font-black uppercase text-neo-black"
        >
          <Download size={20} />
          Start Rendering
        </button>

      </div>
    </div>
  );
};

export default ExportModal;
