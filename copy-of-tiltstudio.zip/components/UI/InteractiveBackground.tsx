import React, { useEffect, useRef } from 'react';

interface InteractiveBackgroundProps {
  isDarkMode: boolean;
}

const InteractiveBackground: React.FC<InteractiveBackgroundProps> = ({ isDarkMode }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  // Use refs for mutable values to avoid closure staleness in the animation loop
  const mouseRef = useRef({ x: -1000, y: -1000, targetX: -1000, targetY: -1000 });
  const themeRef = useRef(isDarkMode);

  // Update ref when prop changes
  useEffect(() => {
    themeRef.current = isDarkMode;
  }, [isDarkMode]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;

    const handleResize = () => {
      const parent = canvas.parentElement;
      if (parent) {
        const rect = parent.getBoundingClientRect();
        const dpr = window.devicePixelRatio || 1;
        
        canvas.width = rect.width * dpr;
        canvas.height = rect.height * dpr;
        
        canvas.style.width = `${rect.width}px`;
        canvas.style.height = `${rect.height}px`;
        
        ctx.scale(dpr, dpr);
      }
    };

    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      mouseRef.current.targetX = e.clientX - rect.left;
      mouseRef.current.targetY = e.clientY - rect.top;
    };

    const handleMouseLeave = () => {
        mouseRef.current.targetX = -1000;
        mouseRef.current.targetY = -1000;
    }

    // Configuration
    const GRID_GAP = 40;
    const NEEDLE_LENGTH = 15;
    const MOUSE_LERP = 0.15; // Lower = smoother/slower, Higher = snappier

    const render = () => {
      const width = canvas.width / (window.devicePixelRatio || 1);
      const height = canvas.height / (window.devicePixelRatio || 1);
      const isDark = themeRef.current;

      // Smooth mouse movement
      mouseRef.current.x += (mouseRef.current.targetX - mouseRef.current.x) * MOUSE_LERP;
      mouseRef.current.y += (mouseRef.current.targetY - mouseRef.current.y) * MOUSE_LERP;

      // Clear
      ctx.clearRect(0, 0, width, height);

      // Colors
      const baseColor = isDark ? '#333333' : '#E5E7EB'; // Passive color
      const activeColor = isDark ? '#A5F3FC' : '#121212'; // Active color (Blue or Black)

      ctx.lineWidth = 2;
      ctx.lineCap = 'round';

      for (let x = GRID_GAP / 2; x < width; x += GRID_GAP) {
        for (let y = GRID_GAP / 2; y < height; y += GRID_GAP) {
          const dx = mouseRef.current.x - x;
          const dy = mouseRef.current.y - y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          
          // Calculate angle
          let angle = Math.atan2(dy, dx);
          
          // Influence calculation
          const maxDist = 400;
          const influence = Math.max(0, 1 - dist / maxDist);
          
          // Save context
          ctx.save();
          ctx.translate(x, y);
          ctx.rotate(angle);

          // Draw Needle
          ctx.strokeStyle = dist < maxDist ? activeColor : baseColor;
          ctx.globalAlpha = dist < maxDist ? 1 : 0.5;
          
          // Scale length slightly by influence
          const len = NEEDLE_LENGTH * (0.5 + influence * 0.5);

          ctx.beginPath();
          ctx.moveTo(-len / 2, 0);
          ctx.lineTo(len / 2, 0);
          ctx.stroke();

          // Draw Pivot Dot
          if (influence > 0.1) {
              ctx.fillStyle = activeColor;
              ctx.beginPath();
              ctx.arc(0, 0, 1.5, 0, Math.PI * 2);
              ctx.fill();
          }

          ctx.restore();
        }
      }

      animationFrameId = requestAnimationFrame(render);
    };

    window.addEventListener('resize', handleResize);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseleave', handleMouseLeave);
    
    handleResize();
    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseleave', handleMouseLeave);
      cancelAnimationFrame(animationFrameId);
    };
  }, []); // Empty deps, we use refs for dynamic values

  return (
    <canvas 
      ref={canvasRef} 
      className="absolute inset-0 w-full h-full pointer-events-none z-0"
    />
  );
};

export default InteractiveBackground;