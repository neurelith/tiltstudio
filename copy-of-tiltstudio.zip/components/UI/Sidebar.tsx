import React, { useState, useRef } from 'react';
import { SceneSettings, Preset, BackgroundType, PresetName, Keyframe, InterpolationType, ZoomType, TextAnimationType } from '../../types';
import { PRESETS } from '../../constants';
import { 
  Maximize, 
  Layers, 
  Aperture, 
  Sun, 
  Grid, 
  Box, 
  Ghost, 
  Play, 
  LayoutTemplate,
  Monitor,
  Scan,
  Zap,
  Crosshair,
  Vibrate,
  Plus,
  Trash2,
  TrendingUp,
  Type,
  Move3d,
  Palette,
  Timer,
  Image as ImageIcon,
  Upload,
  MousePointer2,
  ArrowUpLeft,
  ArrowDownRight,
  Maximize2
} from 'lucide-react';

interface SidebarProps {
  settings: SceneSettings;
  updateSettings: (newSettings: Partial<SceneSettings>) => void;
  applyPreset: (presetId: PresetName) => void;
  currentTime: number;
}

const ControlGroup = ({ title, icon: Icon, children }: { title: string, icon: any, children: React.ReactNode }) => (
  <div className="mb-10 p-4 border-2 border-neo-black dark:border-white bg-white dark:bg-neo-gray shadow-neo dark:shadow-neo-white transition-colors">
    <div className="flex items-center gap-2 mb-4 text-neo-black dark:text-white border-b-2 border-neo-black dark:border-white pb-2">
      <Icon size={20} strokeWidth={2.5} />
      <span className="text-sm font-black uppercase tracking-wider">{title}</span>
    </div>
    <div className="space-y-5">
      {children}
    </div>
  </div>
);

const Slider = ({ label, value, min, max, step, onChange }: { label: string, value: number, min: number, max: number, step: number, onChange: (val: number) => void }) => {
  const safeValue = isNaN(value) ? min : value;
  const percentage = Math.min(100, Math.max(0, ((safeValue - min) / (max - min)) * 100));
  
  return (
    <div className="group">
      <div className="flex justify-between mb-2">
        <label className="text-sm font-bold text-neo-black dark:text-white">{label}</label>
        <span className="text-xs font-mono bg-neo-black dark:bg-white text-white dark:text-neo-black px-2 py-0.5 rounded-sm font-bold">
            {safeValue.toFixed(2)}
        </span>
      </div>
      <div className="relative h-6 flex items-center">
          <input 
          type="range" 
          min={min} 
          max={max} 
          step={step} 
          value={safeValue} 
          onChange={(e) => {
             const v = parseFloat(e.target.value);
             if (!isNaN(v)) {
                 onChange(v);
             }
          }}
          className="w-full absolute z-20 opacity-0 cursor-pointer h-full inset-0 m-0 p-0 appearance-none"
          />
          {/* Custom Track */}
          <div className="w-full h-3 bg-white dark:bg-neo-black border-2 border-neo-black dark:border-white relative overflow-hidden pointer-events-none">
               {/* Fill */}
               <div 
                  className="h-full bg-pastel-green dark:bg-pastel-blue border-r-2 border-neo-black dark:border-white" 
                  style={{ width: `${percentage}%` }}
               />
          </div>
          {/* Custom Thumb (Visual Only) */}
          <div 
              className="absolute h-6 w-3 bg-neo-black dark:bg-white pointer-events-none transition-all z-10 border-2 border-transparent"
              style={{ left: `calc(${percentage}% - 6px)` }}
          />
      </div>
    </div>
  );
};

const Toggle = ({ label, checked, onChange }: { label: string, checked: boolean, onChange: (val: boolean) => void }) => (
  <div className="flex items-center justify-between py-1">
    <span className="text-sm font-bold text-neo-black dark:text-white">{label}</span>
    <button 
      onClick={() => onChange(!checked)}
      className={`relative w-12 h-6 border-2 border-neo-black dark:border-white transition-colors duration-200 ease-in-out ${checked ? 'bg-pastel-pink dark:bg-pastel-pink' : 'bg-gray-200 dark:bg-neo-black'}`}
    >
      <span className={`absolute top-0 left-0 w-5 h-5 bg-neo-black dark:bg-white border-2 border-neo-black dark:border-white transition-transform duration-200 ease-in-out ${checked ? 'translate-x-6 bg-white dark:bg-neo-black' : 'translate-x-0'}`} />
    </button>
  </div>
);

const Sidebar: React.FC<SidebarProps> = ({ settings, updateSettings, applyPreset, currentTime }) => {
  const [newText, setNewText] = useState("New Text");
  const [selectedKeyframeId, setSelectedKeyframeId] = useState<string | null>(null);
  const bgInputRef = useRef<HTMLInputElement>(null);

  const updateZoom = (changes: Partial<typeof settings.zoom>) => {
      updateSettings({ zoom: { ...settings.zoom, ...changes } });
  };

  const updateKeyframe = (id: string, updates: Partial<Keyframe>) => {
      const newKeys = settings.zoom.keyframes.map(k => k.id === id ? { ...k, ...updates } : k);
      updateZoom({ keyframes: newKeys });
  };

  const removeKeyframe = (id: string) => {
      const newKeys = settings.zoom.keyframes.filter(k => k.id !== id);
      updateZoom({ keyframes: newKeys });
      if (selectedKeyframeId === id) setSelectedKeyframeId(null);
  };

  const addTextLayer = () => {
    updateSettings({
        textLayers: [
            ...settings.textLayers,
            {
                id: Math.random().toString(36).substr(2, 9),
                text: newText,
                fontSize: 0.5,
                color: '#FFFFFF',
                position: { x: 0, y: 0 },
                opacity: 1,
                animation: { type: 'none', duration: 1, startDelay: currentTime * 10 }
            }
        ]
    });
  };

  const updateTextLayer = (id: string, updates: Partial<typeof settings.textLayers[0]> | { animation: Partial<typeof settings.textLayers[0]['animation']> }) => {
      const newLayers = settings.textLayers.map(l => {
          if (l.id !== id) return l;
          if ('animation' in updates) {
              return { ...l, animation: { ...l.animation, ...updates.animation } };
          }
          return { ...l, ...updates };
      });
      updateSettings({ textLayers: newLayers });
  };

  const removeTextLayer = (id: string) => {
      const newLayers = settings.textLayers.filter(l => l.id !== id);
      updateSettings({ textLayers: newLayers });
  };

  const handleBgUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files && e.target.files.length > 0) {
          const file = e.target.files[0];
          const url = URL.createObjectURL(file);
          const isExr = file.name.toLowerCase().endsWith('.exr');
          updateSettings({ 
              background: 'custom',
              customBackground: url,
              customBackgroundIsExr: isExr
          });
      }
  };

  const selectedKeyframe = settings.zoom.keyframes.find(k => k.id === selectedKeyframeId);

  return (
    <div className="h-full w-96 bg-pastel-yellow dark:bg-neo-black border-l-2 border-neo-black dark:border-white p-6 overflow-y-auto transition-colors duration-300">
      
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-2xl font-black text-neo-black dark:text-white uppercase italic">Controls</h2>
        <div className="w-4 h-4 bg-pastel-green dark:bg-pastel-blue border-2 border-neo-black dark:border-white shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] dark:shadow-[2px_2px_0px_0px_rgba(255,255,255,1)] animate-bounce"></div>
      </div>

      {/* Magic Presets */}
      <ControlGroup title="Vibe Gallery" icon={LayoutTemplate}>
        <div className="grid grid-cols-2 gap-3">
            {PRESETS.map((preset) => (
                <button
                    key={preset.id}
                    onClick={() => applyPreset(preset.id)}
                    className="px-3 py-3 text-xs font-bold text-left bg-neo-white dark:bg-neo-black text-neo-black dark:text-white border-2 border-neo-black dark:border-white shadow-neo-sm dark:shadow-neo-sm-white hover:translate-x-[1px] hover:translate-y-[1px] hover:shadow-none hover:bg-pastel-blue dark:hover:bg-pastel-blue dark:hover:text-neo-black transition-all active:bg-pastel-pink"
                >
                    {preset.name}
                </button>
            ))}
        </div>
      </ControlGroup>

      {/* Layers & Text */}
      <ControlGroup title="Layers & Text" icon={Layers}>
          <Slider 
             label="Media Opacity" 
             value={settings.videoOpacity} 
             min={0} max={1} step={0.01} 
             onChange={(v) => updateSettings({ videoOpacity: v })} 
          />
          
          <div className="h-px bg-neo-black dark:bg-white opacity-20 my-2"></div>
          
          <div className="flex gap-2">
              <input 
                type="text" 
                value={newText} 
                onChange={(e) => setNewText(e.target.value)}
                className="flex-1 bg-white dark:bg-neo-black border-2 border-neo-black dark:border-white px-2 py-1 text-xs font-mono text-neo-black dark:text-white"
              />
              <button 
                onClick={addTextLayer}
                className="bg-neo-black dark:bg-white text-white dark:text-neo-black p-2 font-bold uppercase text-xs hover:opacity-80"
              >
                  <Plus size={14} />
              </button>
          </div>

          <div className="space-y-4 mt-2">
              {settings.textLayers.map(layer => (
                  <div key={layer.id} className="bg-gray-100 dark:bg-gray-800 p-2 border border-neo-black dark:border-white">
                      <div className="flex justify-between items-center mb-2">
                          <span className="text-xs font-bold truncate">{layer.text}</span>
                          <button onClick={() => removeTextLayer(layer.id)}><Trash2 size={12} className="text-red-500" /></button>
                      </div>
                      <div className="grid grid-cols-2 gap-2 mb-2">
                           <Slider label="Size" value={layer.fontSize} min={0.1} max={2} step={0.1} onChange={(v) => updateTextLayer(layer.id, { fontSize: v })} />
                           <Slider label="Opac" value={layer.opacity} min={0} max={1} step={0.1} onChange={(v) => updateTextLayer(layer.id, { opacity: v })} />
                      </div>
                      
                      <div className="grid grid-cols-2 gap-2 mb-2">
                           <Slider label="Pos X" value={layer.position.x} min={-1} max={1} step={0.05} onChange={(v) => updateTextLayer(layer.id, { position: { ...layer.position, x: v } })} />
                           <Slider label="Pos Y" value={layer.position.y} min={-1} max={1} step={0.05} onChange={(v) => updateTextLayer(layer.id, { position: { ...layer.position, y: v } })} />
                      </div>
                      
                      {/* Text Animation Controls */}
                      <div className="border-t border-gray-300 dark:border-gray-600 pt-2">
                        <div className="flex items-center gap-1 mb-2">
                            <Timer size={10} />
                            <span className="text-[10px] font-bold uppercase text-gray-500">Animation</span>
                        </div>
                        <select 
                            value={layer.animation.type}
                            onChange={(e) => updateTextLayer(layer.id, { animation: { type: e.target.value as TextAnimationType } })}
                            className="w-full text-xs p-1 mb-2 border border-gray-300"
                        >
                            <option value="none">None</option>
                            <option value="fade-in">Fade In</option>
                            <option value="slide-in">Slide In</option>
                            <option value="typewriter">Typewriter</option>
                        </select>
                        <div className="grid grid-cols-2 gap-2">
                            <Slider label="Delay (s)" value={layer.animation.startDelay} min={0} max={10} step={0.1} onChange={(v) => updateTextLayer(layer.id, { animation: { startDelay: v } })} />
                            <Slider label="Dur (s)" value={layer.animation.duration} min={0.1} max={5} step={0.1} onChange={(v) => updateTextLayer(layer.id, { animation: { duration: v } })} />
                        </div>
                      </div>
                  </div>
              ))}
          </div>
      </ControlGroup>

      {/* New KEYFRAME ZOOM Panel */}
      <ControlGroup title="Smart Zoom" icon={Scan}>
          <div className="flex gap-2">
            <button
                onClick={() => updateZoom({ picking: !settings.zoom.picking, active: false })}
                className={`flex-1 flex items-center justify-center gap-2 py-3 text-xs font-black uppercase border-2 border-neo-black dark:border-white transition-all ${settings.zoom.picking ? 'bg-red-500 text-white animate-pulse' : 'bg-white dark:bg-neo-black text-neo-black dark:text-white hover:bg-gray-100'}`}
            >
                <Plus size={16} />
                {settings.zoom.picking ? 'Click Media...' : 'Add Keyframe'}
            </button>

            <button
                onClick={() => updateZoom({ active: !settings.zoom.active, picking: false })}
                className={`flex-1 flex items-center justify-center gap-2 py-3 text-xs font-black uppercase border-2 border-neo-black dark:border-white transition-all ${settings.zoom.active ? 'bg-pastel-green text-neo-black shadow-none translate-x-[2px] translate-y-[2px]' : 'bg-neo-black text-white shadow-neo-sm hover:translate-x-[1px] hover:translate-y-[1px] hover:shadow-none'}`}
            >
                <Zap size={16} fill={settings.zoom.active ? "currentColor" : "none"} />
                {settings.zoom.active ? 'Active' : 'Enable Zoom'}
            </button>
          </div>
          
          {/* Zoom Type Selector */}
          <div className="mt-4">
              <label className="text-xs font-bold text-neo-black dark:text-white mb-2 block uppercase">Zoom Type</label>
              <select 
                value={settings.zoom.type}
                onChange={(e) => updateZoom({ type: e.target.value as ZoomType })}
                className="w-full bg-white dark:bg-neo-black border-2 border-neo-black dark:border-white p-2 text-xs font-bold uppercase"
              >
                  <option value="custom">Custom (Keyframes)</option>
                  <option value="in-out">In & Out (Boomerang)</option>
                  <option value="in-only">In Only</option>
                  <option value="out-only">Out Only</option>
                  <option value="constant">Constant Zoom</option>
                  <option value="static">Static</option>
              </select>
          </div>
          
          {/* Zoom Length Slider */}
          <div className="mt-4">
               <Slider 
                label="Zoom Length (s)" 
                value={settings.zoom.zoomDuration} 
                min={0} max={10} step={0.5} 
                onChange={(v) => updateZoom({ zoomDuration: v })} 
              />
              <p className="text-[10px] text-gray-500 mt-1">
                  0 = Match Video Duration. Controls speed of presets.
              </p>
          </div>

          <div className="h-px bg-neo-black dark:bg-white opacity-20 my-4"></div>

          {/* Keyframe List & Pivot Controls */}
          {settings.zoom.type === 'custom' && (
              <div className="space-y-2 mb-4">
                  <label className="text-xs font-bold text-gray-500 uppercase">Keyframes</label>
                  {settings.zoom.keyframes.length === 0 && (
                      <div className="text-xs text-gray-400 italic">No keyframes. Move playhead and click 'Add Keyframe'.</div>
                  )}
                  {settings.zoom.keyframes.map((kf, i) => (
                      <div 
                        key={kf.id} 
                        onClick={() => setSelectedKeyframeId(kf.id === selectedKeyframeId ? null : kf.id)}
                        className={`
                            flex items-center justify-between text-xs font-mono p-2 border cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-900
                            ${selectedKeyframeId === kf.id 
                                ? 'bg-pastel-blue dark:bg-pastel-blue text-neo-black border-neo-black dark:border-white' 
                                : 'bg-gray-100 dark:bg-gray-800 border-neo-black dark:border-white text-neo-black dark:text-white'
                            }
                        `}
                      >
                          <span>{(kf.timestamp * 100).toFixed(1)}%</span>
                          <span className="text-gray-500">Z:{kf.intensity.toFixed(1)}</span>
                          <button onClick={(e) => { e.stopPropagation(); removeKeyframe(kf.id); }} className="text-red-500 hover:text-red-700">
                              <Trash2 size={12} />
                          </button>
                      </div>
                  ))}

                  {/* Selected Keyframe Controls */}
                  {selectedKeyframe && (
                      <div className="mt-4 p-3 bg-white dark:bg-neo-black border-2 border-neo-black dark:border-white shadow-neo-sm">
                          <div className="flex items-center gap-2 mb-3 pb-2 border-b border-gray-200 dark:border-gray-700">
                                <MousePointer2 size={14} className="text-neo-black dark:text-white" />
                                <span className="text-xs font-black uppercase">Pivot Control</span>
                          </div>
                          
                          <div className="space-y-3">
                              <Slider 
                                label="Target X" 
                                value={selectedKeyframe.target.x} 
                                min={0} max={1} step={0.01} 
                                onChange={(v) => updateKeyframe(selectedKeyframe.id, { target: { ...selectedKeyframe.target, x: v } })} 
                              />
                              <Slider 
                                label="Target Y" 
                                value={selectedKeyframe.target.y} 
                                min={0} max={1} step={0.01} 
                                onChange={(v) => updateKeyframe(selectedKeyframe.id, { target: { ...selectedKeyframe.target, y: v } })} 
                              />
                              
                              <div className="grid grid-cols-3 gap-1 mt-2">
                                  <button 
                                    onClick={() => updateKeyframe(selectedKeyframe.id, { target: { x: 0, y: 1 } })}
                                    className="p-1 border border-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 flex flex-col items-center gap-1"
                                    title="Top Left"
                                  >
                                      <ArrowUpLeft size={12} />
                                      <span className="text-[9px] uppercase font-bold">TL</span>
                                  </button>
                                  <button 
                                    onClick={() => updateKeyframe(selectedKeyframe.id, { target: { x: 0.5, y: 0.5 } })}
                                    className="p-1 border border-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 flex flex-col items-center gap-1"
                                    title="Center"
                                  >
                                      <Maximize2 size={12} />
                                      <span className="text-[9px] uppercase font-bold">CTR</span>
                                  </button>
                                  <button 
                                    onClick={() => updateKeyframe(selectedKeyframe.id, { target: { x: 1, y: 0 } })}
                                    className="p-1 border border-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 flex flex-col items-center gap-1"
                                    title="Bottom Right"
                                  >
                                      <ArrowDownRight size={12} />
                                      <span className="text-[9px] uppercase font-bold">BR</span>
                                  </button>
                              </div>
                          </div>
                      </div>
                  )}
              </div>
          )}
          
          <div className="h-px bg-neo-black dark:bg-white opacity-20 my-4"></div>

          {/* Interpolation Settings */}
          <div className="mb-4">
              <label className="text-xs font-bold text-neo-black dark:text-white mb-2 block uppercase">Animation Curve</label>
              <div className="flex gap-1 flex-wrap">
                  {(['linear', 'ease', 'bounce', 'elastic'] as InterpolationType[]).map((type) => (
                      <button
                          key={type}
                          onClick={() => updateZoom({ interpolation: type })}
                          className={`flex-1 min-w-[60px] py-2 text-[10px] font-bold uppercase border-2 transition-all ${settings.zoom.interpolation === type ? 'bg-pastel-blue text-neo-black border-neo-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]' : 'border-gray-200 text-gray-500 hover:border-gray-400'}`}
                      >
                          {type}
                      </button>
                  ))}
              </div>
          </div>
          
          <div className="h-px bg-neo-black dark:bg-white opacity-20 my-4"></div>

          {/* Background Effects */}
          <div className="mb-4">
              <div className="flex items-center gap-2 mb-2">
                  <Palette size={14} />
                  <span className="text-xs font-bold uppercase">Background FX</span>
              </div>
              <Toggle 
                label="Colored Backing" 
                checked={settings.zoom.background} 
                onChange={(v) => updateZoom({ background: v })} 
              />
              <Toggle 
                label="Drop Shadow" 
                checked={settings.zoom.dropShadow} 
                onChange={(v) => updateZoom({ dropShadow: v })} 
              />
          </div>

          <div className="h-px bg-neo-black dark:bg-white opacity-20 my-4"></div>

          <Slider 
            label="Camera Shake" 
            value={settings.zoom.shake} 
            min={0} max={1} step={0.1} 
            onChange={(v) => updateZoom({ shake: v })} 
          />
      </ControlGroup>

      {/* Perspective Tilt */}
      <ControlGroup title="Perspective" icon={Maximize}>
        <Slider 
            label="Scale" 
            value={settings.scale} 
            min={0.5} max={2} step={0.1} 
            onChange={(v) => updateSettings({ scale: v })} 
        />
      </ControlGroup>

      {/* Dimensions: Keyframe Specific Rotation and Extrusion */}
      <ControlGroup title="Dimensions" icon={Box}>
        <div className="mb-4">
            <div className="flex items-center gap-2 mb-2">
                 <Move3d size={14} />
                 <span className="text-xs font-bold uppercase text-neo-black dark:text-white">Keyframe Rotation</span>
            </div>
             <p className="text-[10px] text-gray-500 mb-2 leading-tight">
                Sets the rotation target for the <strong>next</strong> created keyframe or current global rotation.
            </p>
             <Slider 
                label="Pitch (X)" 
                value={settings.rotation.x} 
                min={-1.5} max={1.5} step={0.01} 
                onChange={(v) => updateSettings({ rotation: { ...settings.rotation, x: v } })} 
              />
              <Slider 
                label="Yaw (Y)" 
                value={settings.rotation.y} 
                min={-1.5} max={1.5} step={0.01} 
                onChange={(v) => updateSettings({ rotation: { ...settings.rotation, y: v } })} 
              />
        </div>

        <div className="h-px bg-neo-black dark:bg-white opacity-20 my-4"></div>

        <Slider 
            label="Extrusion Depth" 
            value={settings.extrusion} 
            min={0} max={2} step={0.1} 
            onChange={(v) => updateSettings({ extrusion: v })} 
        />
        <Slider 
            label="Corner Radius" 
            value={settings.borderRadius} 
            min={0} max={0.5} step={0.01} 
            onChange={(v) => updateSettings({ borderRadius: v })} 
        />
      </ControlGroup>

      {/* Environment */}
      <ControlGroup title="Environment" icon={Grid}>
        <div className="flex border-2 border-neo-black dark:border-white bg-white dark:bg-neo-black p-1 mb-4 gap-1 flex-wrap">
            {(['studio', 'mesh', 'transparent', 'windows11', 'real-world', 'desktop-screen', 'custom'] as BackgroundType[]).map((bg) => (
                <button
                    key={bg}
                    onClick={() => updateSettings({ background: bg })}
                    className={`flex-1 min-w-[60px] py-1.5 text-[10px] font-bold uppercase transition-all border-2 ${settings.background === bg ? 'bg-pastel-yellow dark:bg-white text-neo-black border-neo-black dark:border-white shadow-neo-sm' : 'border-transparent text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'}`}
                >
                    {bg.replace('-', ' ').substring(0, 7)}
                </button>
            ))}
        </div>
        
        {settings.background === 'custom' && (
             <div className="mb-4">
                 <button 
                    onClick={() => bgInputRef.current?.click()}
                    className="w-full flex items-center justify-center gap-2 py-2 bg-neo-black text-white text-xs font-bold uppercase hover:opacity-80 transition-opacity"
                 >
                     <Upload size={14} /> Upload Background
                 </button>
                 <input 
                    type="file" 
                    ref={bgInputRef} 
                    onChange={handleBgUpload} 
                    className="hidden" 
                    accept="image/*,.exr"
                 />
                 {settings.customBackground && (
                     <div className="mt-2 text-[10px] text-gray-500 truncate">
                         Active: Custom Image
                     </div>
                 )}
             </div>
        )}

        <Slider 
            label="Floor Reflection" 
            value={settings.reflectionOpacity} 
            min={0} max={1} step={0.1} 
            onChange={(v) => updateSettings({ reflectionOpacity: v })} 
        />
      </ControlGroup>

      {/* Effects */}
      <ControlGroup title="Post FX" icon={Aperture}>
        <Toggle 
            label="Motion Blur (Fake)" 
            checked={settings.motionBlur} 
            onChange={(v) => updateSettings({ motionBlur: v })} 
        />
        <p className="text-[10px] font-bold bg-pastel-blue/30 dark:bg-pastel-blue/10 p-2 border-2 border-dashed border-neo-black dark:border-gray-500 text-neo-black dark:text-gray-300 mb-4">Adds float movement & subtle blur</p>

        <Toggle 
            label="Backlight Glow" 
            checked={settings.glow} 
            onChange={(v) => updateSettings({ glow: v })} 
        />
      </ControlGroup>
      
      {/* Preview */}
       <div className="p-4 border-2 border-neo-black dark:border-white bg-pastel-pink dark:bg-pastel-pink shadow-neo dark:shadow-neo-white">
        <button
            onClick={() => updateSettings({ orbitPreview: !settings.orbitPreview })}
            className={`w-full flex items-center justify-center gap-2 py-3 font-black uppercase text-sm border-2 border-neo-black transition-all ${
                settings.orbitPreview 
                ? 'bg-neo-black text-white shadow-none translate-x-[4px] translate-y-[4px]' 
                : 'bg-white text-neo-black shadow-neo hover:translate-x-[2px] hover:translate-y-[2px] hover:shadow-neo-sm'
            }`}
        >
           {settings.orbitPreview ? <Play size={16} fill="currentColor" /> : <Play size={16} />} 
           {settings.orbitPreview ? 'Orbiting...' : 'Orbit Preview'}
        </button>
      </div>
      <div className="h-20"></div> {/* Spacer */}
    </div>
  );
};

export default Sidebar;