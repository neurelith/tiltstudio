import React, { useRef, useState, useEffect } from 'react';
import { Play, Pause, ChevronLeft, ChevronRight } from 'lucide-react';
import { Keyframe } from '../../types';

interface TimelineProps {
    currentTime: number; // 0 to 1
    duration: number; // Seconds
    isPlaying: boolean;
    onPlayPause: () => void;
    onSeek: (time: number) => void;
    keyframes: Keyframe[];
    onKeyframeUpdate: (id: string, newTimestamp: number) => void;
}

const Timeline: React.FC<TimelineProps> = ({ 
    currentTime, 
    duration, 
    isPlaying, 
    onPlayPause, 
    onSeek,
    keyframes,
    onKeyframeUpdate
}) => {
  const timelineRef = useRef<HTMLDivElement>(null);
  
  const [isDraggingPlayhead, setIsDraggingPlayhead] = useState(false);
  const [draggingKeyframeId, setDraggingKeyframeId] = useState<string | null>(null);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    const ms = Math.floor((seconds % 1) * 100);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}:${ms.toString().padStart(2, '0')}`;
  };

  // Global Mouse Up / Move handlers to ensure smooth dragging even if mouse leaves component
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
        if (!timelineRef.current) return;
        const rect = timelineRef.current.getBoundingClientRect();
        
        // Calculate percentage position within the timeline track area
        let pct = (e.clientX - rect.left) / rect.width;
        pct = Math.max(0, Math.min(1, pct));

        if (isDraggingPlayhead) {
            onSeek(pct);
        } else if (draggingKeyframeId) {
            onKeyframeUpdate(draggingKeyframeId, pct);
        }
    };

    const handleMouseUp = () => {
        setIsDraggingPlayhead(false);
        setDraggingKeyframeId(null);
    };

    if (isDraggingPlayhead || draggingKeyframeId) {
        window.addEventListener('mousemove', handleMouseMove);
        window.addEventListener('mouseup', handleMouseUp);
    }

    return () => {
        window.removeEventListener('mousemove', handleMouseMove);
        window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDraggingPlayhead, draggingKeyframeId, onSeek, onKeyframeUpdate]);


  // Handle clicking on the ruler to jump playhead
  const handleRulerMouseDown = (e: React.MouseEvent) => {
      setIsDraggingPlayhead(true);
      if (timelineRef.current) {
          const rect = timelineRef.current.getBoundingClientRect();
          let pct = (e.clientX - rect.left) / rect.width;
          onSeek(Math.max(0, Math.min(1, pct)));
      }
  };

  // Step frames logic
  const stepFrame = (direction: 1 | -1) => {
      const frameTime = 1 / 30; 
      const stepPct = frameTime / duration;
      let newTime = currentTime + (stepPct * direction);
      if (newTime < 0) newTime = 0;
      if (newTime > 1) newTime = 1;
      onSeek(newTime);
  };

  const LabelBox = ({ label, active = false }: { label: string, active?: boolean }) => (
    <div className={`
        h-10 flex items-center px-2 text-[10px] font-black uppercase tracking-wider border-2 
        ${active 
            ? 'border-neo-black dark:border-white bg-white dark:bg-neo-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] dark:shadow-[2px_2px_0px_0px_rgba(255,255,255,1)] text-neo-black dark:text-white' 
            : 'border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 text-gray-400 dark:text-gray-500'
        }
    `}>
        {label}
    </div>
  );

  return (
    <div className="w-full h-64 bg-white dark:bg-neo-gray border-t-2 border-neo-black dark:border-white flex flex-col transition-colors select-none">
      
      {/* 1. Toolbar */}
      <div className="h-12 border-b-2 border-neo-black dark:border-white bg-pastel-yellow dark:bg-neo-black flex items-center px-4 justify-between transition-colors z-20 relative">
         <div className="flex items-center gap-2">
             <button 
                onClick={onPlayPause}
                className="w-8 h-8 flex items-center justify-center bg-white dark:bg-neo-gray border-2 border-neo-black dark:border-white shadow-neo-sm dark:shadow-neo-sm-white hover:translate-x-[1px] hover:translate-y-[1px] hover:shadow-none transition-all active:bg-pastel-blue"
             >
                 {isPlaying ? <Pause size={14} fill="currentColor" className="text-neo-black dark:text-white" /> : <Play size={14} fill="currentColor" className="text-neo-black dark:text-white" />}
             </button>
             
             <div className="flex items-center gap-1 mx-2">
                 <button onClick={() => stepFrame(-1)} className="p-1 hover:bg-black/10 dark:hover:bg-white/10 rounded">
                    <ChevronLeft size={16} />
                 </button>
                 <button onClick={() => stepFrame(1)} className="p-1 hover:bg-black/10 dark:hover:bg-white/10 rounded">
                    <ChevronRight size={16} />
                 </button>
             </div>

             <div className="text-sm font-black font-mono text-neo-black dark:text-white bg-white dark:bg-neo-gray border-2 border-neo-black dark:border-white px-2 py-0.5">
                {formatTime(currentTime * duration)}
             </div>
         </div>
         
         <div className="flex items-center gap-2">
            <span className="text-xs uppercase bg-neo-black dark:bg-white text-white dark:text-neo-black px-2 py-1 font-bold tracking-widest">
                {Math.round(currentTime * 100)}%
            </span>
         </div>
      </div>

      {/* 2. Main Timeline Area */}
      <div className="flex-1 flex relative">
        
        {/* Left Sidebar (Labels) */}
        <div className="w-32 shrink-0 border-r-2 border-neo-black dark:border-white bg-gray-50 dark:bg-neo-darkgray flex flex-col pt-8 p-2 gap-2 z-10">
            {/* The 'pt-8' aligns labels with the tracks below the ruler */}
            <LabelBox label="Zoom" active={true} />
            <LabelBox label="Rotation" />
            <LabelBox label="Depth" />
        </div>

        {/* Right Timeline Content */}
        <div className="flex-1 flex flex-col relative" ref={timelineRef}>
            
            {/* Scrubber Ruler */}
            <div 
                className="h-8 bg-gray-100 dark:bg-neo-gray border-b-2 border-neo-black dark:border-white relative cursor-pointer group"
                onMouseDown={handleRulerMouseDown}
            >
                {/* Ticks Pattern */}
                <div className="absolute inset-0 opacity-20 pointer-events-none" 
                     style={{ backgroundImage: 'linear-gradient(to right, black 1px, transparent 1px)', backgroundSize: '20px 100%' }}></div>
                <div className="absolute inset-0 opacity-40 pointer-events-none" 
                     style={{ backgroundImage: 'linear-gradient(to right, black 1px, transparent 1px)', backgroundSize: '100px 100%' }}></div>
            </div>

            {/* Tracks Container */}
            <div className="flex-1 p-2 gap-2 flex flex-col relative bg-gray-50 dark:bg-black overflow-hidden">
                
                {/* Zoom Track */}
                <div className="h-10 bg-white dark:bg-neo-black border-2 border-neo-black dark:border-white relative group">
                    {/* Render Keyframes */}
                    {keyframes.map((kf) => (
                        <div
                        key={kf.id}
                        onMouseDown={(e) => { e.stopPropagation(); setDraggingKeyframeId(kf.id); }}
                        className={`
                            absolute top-1/2 -translate-y-1/2 w-3 h-3 border-2 border-neo-black dark:border-white rotate-45 cursor-ew-resize z-20 
                            transition-transform hover:scale-150
                            ${draggingKeyframeId === kf.id ? 'bg-pastel-pink scale-150' : 'bg-pastel-blue'}
                        `}
                        style={{ left: `calc(${kf.timestamp * 100}% - 6px)` }}
                        title={`Keyframe: ${(kf.timestamp * 100).toFixed(1)}%`}
                        />
                    ))}
                    {/* Line connecting */}
                    <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-gray-200 dark:bg-gray-800 pointer-events-none"></div>
                </div>

                {/* Dummy Tracks */}
                <div className="h-10 bg-gray-100 dark:bg-gray-900 border-2 border-gray-200 dark:border-gray-800 opacity-50 relative"></div>
                <div className="h-10 bg-gray-100 dark:bg-gray-900 border-2 border-gray-200 dark:border-gray-800 opacity-50 relative"></div>
            </div>

            {/* Global Playhead Overlay */}
            {/* This sits on top of everything in the right column to allow the line to span Ruler + Tracks */}
            <div className="absolute inset-0 pointer-events-none z-50">
                <div 
                    className="absolute top-0 bottom-0 w-px bg-red-500 shadow-[0_0_10px_rgba(239,68,68,0.5)]"
                    style={{ left: `${currentTime * 100}%` }}
                >
                    {/* Playhead Handle (Draggable Target) - Positioned inside the ruler area */}
                    <div 
                        className="absolute top-0 -translate-x-1/2 w-0 h-0 border-l-[8px] border-l-transparent border-r-[8px] border-r-transparent border-t-[12px] border-t-red-500 pointer-events-auto cursor-ew-resize hover:scale-110 transition-transform"
                        onMouseDown={(e) => { e.stopPropagation(); setIsDraggingPlayhead(true); }}
                    />
                     {/* Triangle Grip Shadow/Stroke fix */}
                     <div 
                        className="absolute top-[-1px] -translate-x-1/2 w-0 h-0 border-l-[8px] border-l-transparent border-r-[8px] border-r-transparent border-t-[12px] border-t-red-500 opacity-50 blur-[2px]"
                    />
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default Timeline;