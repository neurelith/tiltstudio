
export type BackgroundType = 'studio' | 'mesh' | 'transparent' | 'windows11' | 'real-world' | 'desktop-screen' | 'custom';

export type MediaType = 'video' | 'image';

export type InterpolationType = 'linear' | 'ease' | 'bounce' | 'elastic';

export type ZoomType = 'custom' | 'in-out' | 'in-only' | 'out-only' | 'constant' | 'static';

export type TextAnimationType = 'none' | 'fade-in' | 'slide-in' | 'typewriter';

export interface TextAnimation {
  type: TextAnimationType;
  duration: number; // in seconds (normalized to 0-1 relative to total duration in implementation)
  startDelay: number; // seconds
}

export interface TextLayer {
  id: string;
  text: string;
  fontSize: number;
  color: string;
  position: { x: number; y: number }; // Relative -0.5 to 0.5
  opacity: number;
  animation: TextAnimation;
}

export interface Keyframe {
  id: string;
  timestamp: number; // 0 to 1 (normalized progress)
  target: { x: number; y: number };
  intensity: number;
  rotation: { x: number; y: number; z: number };
  extrusion: number;
}

export interface ZoomSettings {
  active: boolean; // Playback mode vs Edit mode
  picking: boolean; // Currently selecting a target?
  interpolation: InterpolationType;
  type: ZoomType;
  shake: number; // 0 to 1
  background: boolean; // Colored background behind video during zoom
  dropShadow: boolean;
  keyframes: Keyframe[];
  zoomDuration: number; // Duration in seconds for preset zooms
}

export interface SceneSettings {
  rotation: { x: number; y: number; z: number };
  scale: number;
  extrusion: number; // Depth/Thickness
  borderRadius: number;
  reflectionOpacity: number;
  background: BackgroundType;
  customBackground: string | null; // URL for custom background image
  customBackgroundIsExr: boolean; // Flag to check if custom background is EXR
  motionBlur: boolean;
  glow: boolean; // Backlight glow
  ambientLightIntensity: number;
  orbitPreview: boolean; // Auto-rotate camera
  videoOpacity: number; // New: Opacity control for main media
  textLayers: TextLayer[]; // New: Text elements
  zoom: ZoomSettings;
}

export interface VideoState {
  src: string | null;
  aspectRatio: number;
  isPlaying: boolean;
  duration: number;
  currentTime: number;
}

export type PresetName = 'default' | 'saas-launch' | 'mobile-scroll' | 'dark-mode-glow';

export interface Preset {
  name: string;
  id: PresetName;
  settings: Partial<SceneSettings>;
}

export interface ExportSettings {
  resolution: '1080p' | '720p' | '4k';
  fps: 30 | 60;
  format: 'mp4' | 'webm';
}
