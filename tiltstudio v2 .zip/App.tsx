import React, { useState, useEffect } from 'react';
import { SceneSettings, PresetName } from './types';
import { DEFAULT_SETTINGS, PRESETS } from './constants';
import SceneCanvas from './components/Three/SceneCanvas';
import Sidebar from './components/UI/Sidebar';
import DropZone from './components/UI/DropZone';
import Timeline from './components/UI/Timeline';
import InteractiveBackground from './components/UI/InteractiveBackground';
import { Box, Moon, Sun } from 'lucide-react';

const App: React.FC = () => {
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [settings, setSettings] = useState<SceneSettings>(DEFAULT_SETTINGS);
  const [isDarkMode, setIsDarkMode] = useState(false);

  // Toggle Dark Mode Class
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const handleFileSelect = (file: File) => {
    setVideoFile(file);
    const url = URL.createObjectURL(file);
    setVideoUrl(url);
  };

  const updateSettings = (newSettings: Partial<SceneSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  };

  const applyPreset = (presetId: PresetName) => {
    const preset = PRESETS.find(p => p.id === presetId);
    if (preset) {
      updateSettings(preset.settings);
    } else {
        // Reset
      setSettings(DEFAULT_SETTINGS);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-pastel-yellow dark:bg-neo-black text-neo-black dark:text-white font-sans overflow-hidden transition-colors duration-300">
      
      {/* Top Bar */}
      <header className="h-16 border-b-2 border-neo-black dark:border-white bg-pastel-yellow dark:bg-neo-darkgray flex items-center px-6 justify-between z-30 relative transition-colors duration-300">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-pastel-pink dark:bg-neo-gray border-2 border-neo-black dark:border-white shadow-neo-sm dark:shadow-neo-sm-white flex items-center justify-center transition-all">
             <Box size={20} className="text-neo-black dark:text-white" />
          </div>
          <h1 className="text-2xl font-black tracking-tight italic">TiltStudio</h1>
          <span className="px-2 py-0.5 text-xs font-bold bg-pastel-blue text-neo-black border-2 border-neo-black dark:border-white shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] dark:shadow-[2px_2px_0px_0px_rgba(255,255,255,1)]">BETA</span>
        </div>
        <div className="flex items-center gap-4">
             {/* Dark Mode Toggle */}
             <button 
               onClick={() => setIsDarkMode(!isDarkMode)}
               className="p-2 border-2 border-neo-black dark:border-white bg-white dark:bg-neo-gray shadow-neo-sm dark:shadow-neo-sm-white hover:translate-y-[1px] hover:shadow-none transition-all"
             >
               {isDarkMode ? <Sun size={18} /> : <Moon size={18} />}
             </button>

             <button className="px-4 py-2 text-sm font-bold border-2 border-transparent hover:underline transition-colors hidden sm:block">Docs</button>
             <button className="px-6 py-2 text-sm font-bold bg-neo-white dark:bg-neo-black text-neo-black dark:text-white border-2 border-neo-black dark:border-white shadow-neo dark:shadow-neo-white hover:translate-x-[2px] hover:translate-y-[2px] hover:shadow-neo-sm dark:hover:shadow-neo-sm-white transition-all active:translate-x-[4px] active:translate-y-[4px] active:shadow-none">
                Export Video
             </button>
        </div>
      </header>

      {/* Main Workspace */}
      <div className="flex-1 flex overflow-hidden relative">
        
        {/* 3D Viewport / Drop Area */}
        <div className="flex-1 relative bg-white dark:bg-neo-black border-r-2 border-neo-black dark:border-white transition-colors duration-300">
           {!videoUrl ? (
             <div className="absolute inset-0 flex items-center justify-center p-20 z-10 overflow-hidden">
                {/* Interactive Background behind DropZone */}
                <InteractiveBackground isDarkMode={isDarkMode} />
                
                <div className="w-full max-w-xl aspect-video relative z-20">
                  <DropZone onFileSelect={handleFileSelect} />
                </div>
             </div>
           ) : (
             <SceneCanvas 
                videoSrc={videoUrl} 
                settings={settings} 
                updateSettings={updateSettings}
             />
           )}
        </div>

        {/* Right Sidebar */}
        <div className="relative z-20 h-full">
          <Sidebar 
            settings={settings} 
            updateSettings={updateSettings} 
            applyPreset={applyPreset}
          />
        </div>
      </div>

      {/* Bottom Timeline */}
      {videoUrl && (
          <div className="z-20 relative">
            <Timeline />
          </div>
      )}
    </div>
  );
};

export default App;