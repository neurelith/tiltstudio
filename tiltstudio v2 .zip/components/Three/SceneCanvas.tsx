import React, { Suspense, useEffect, useRef, useState } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { 
  OrbitControls, 
  Environment, 
  ContactShadows, 
  MeshReflectorMaterial, 
  RoundedBox, 
  useVideoTexture,
  Float,
  Stars,
  Sparkles,
  Grid,
  Html,
  Sphere
} from '@react-three/drei';
import * as THREE from 'three';
import { SceneSettings, BackgroundType } from '../../types';
import { Crosshair, Move3d } from 'lucide-react';

// Explicitly extend JSX.IntrinsicElements for React Three Fiber primitives
declare module 'react' {
  namespace JSX {
    interface IntrinsicElements {
      group: any;
      mesh: any;
      pointLight: any;
      meshStandardMaterial: any;
      planeGeometry: any;
      meshBasicMaterial: any;
      ambientLight: any;
      spotLight: any;
      color: any;
      ringGeometry: any;
    }
  }
}

interface SceneCanvasProps {
  videoSrc: string;
  settings: SceneSettings;
  updateSettings: (s: Partial<SceneSettings>) => void;
}

// Separate component for the Video Mesh to handle texture hooks
const VideoMesh = ({ 
    videoSrc, 
    settings, 
    onPick 
}: { 
    videoSrc: string; 
    settings: SceneSettings;
    onPick: (uv: THREE.Vector2) => void;
}) => {
  const meshRef = useRef<THREE.Group>(null);
  const settingsRef = useRef(settings);

  useEffect(() => {
    settingsRef.current = settings;
  }, [settings]);

  // Create video texture
  const texture = useVideoTexture(videoSrc, {
    unsuspend: 'canplay',
    muted: true,
    loop: true,
    start: true,
    crossOrigin: 'Anonymous',
  });

  // Safe aspect ratio calculation
  const videoElement = texture.image as HTMLVideoElement;
  const videoWidth = videoElement?.videoWidth || 16;
  const videoHeight = videoElement?.videoHeight || 9;
  const videoAspect = videoHeight > 0 ? videoWidth / videoHeight : 16 / 9;
  
  // Base width of 3 units
  const width = 4;
  const height = width / videoAspect;

  useEffect(() => {
    if (videoElement && videoElement.paused) {
        videoElement.play().catch(e => console.error("Auto-play failed", e));
    }
  }, [videoElement]);

  useFrame((state, delta) => {
    if (meshRef.current) {
      const currentSettings = settingsRef.current;
      
      // If Zoom is active, we might want to stabilize the mesh rotation slightly or keep it
      // For now, we continue to allow rotation adjustments even during zoom for "3D Effect"
      meshRef.current.rotation.x = THREE.MathUtils.lerp(meshRef.current.rotation.x, currentSettings.rotation.x, 0.15);
      meshRef.current.rotation.y = THREE.MathUtils.lerp(meshRef.current.rotation.y, currentSettings.rotation.y, 0.15);
      meshRef.current.rotation.z = THREE.MathUtils.lerp(meshRef.current.rotation.z, currentSettings.rotation.z, 0.15);
      
      const currentScale = meshRef.current.scale.x;
      const targetScale = currentSettings.scale;
      const newScale = THREE.MathUtils.lerp(currentScale, targetScale, 0.15);
      meshRef.current.scale.set(newScale, newScale, newScale);
    }
  });

  const handlePointerDown = (e: any) => {
      if (settings.zoom.picking) {
          e.stopPropagation();
          onPick(e.uv);
      }
  };

  // Calculate local position of the zoom target for visualization
  const targetX = (settings.zoom.target.x - 0.5) * width; // 0.5 offset to center
  const targetY = (settings.zoom.target.y - 0.5) * -height; // Invert Y for 3D space

  return (
    <group>
        <Float 
            speed={settings.motionBlur ? 3 : 0} 
            rotationIntensity={settings.motionBlur ? 0.2 : 0} 
            floatIntensity={settings.motionBlur ? 0.4 : 0}
        >
            <group ref={meshRef}>
                {/* Visual Target Marker (Only visible when picking or zoomed) */}
                {(settings.zoom.picking || settings.zoom.active) && (
                    <group position={[targetX, targetY, settings.extrusion / 2 + 0.02]}>
                        <mesh>
                            <ringGeometry args={[0.05, 0.08, 32]} />
                            <meshBasicMaterial color="#EF4444" opacity={0.8} transparent side={THREE.DoubleSide} />
                        </mesh>
                        <mesh position={[0,0,0]}>
                            <planeGeometry args={[0.02, 0.3]} />
                            <meshBasicMaterial color="#EF4444" />
                        </mesh>
                        <mesh position={[0,0,0]} rotation={[0,0,Math.PI/2]}>
                            <planeGeometry args={[0.02, 0.3]} />
                            <meshBasicMaterial color="#EF4444" />
                        </mesh>
                    </group>
                )}

                {/* Back Glow Light */}
                {settings.glow && (
                    <pointLight position={[0, 0, -2]} intensity={3} color="#F9A8D4" distance={10} />
                )}

                {/* Main Video Body (The Extrusion) */}
                <RoundedBox 
                    args={[width, height, settings.extrusion]} 
                    radius={settings.borderRadius} 
                    smoothness={4}
                    position={[0, 0, 0]}
                >
                    <meshStandardMaterial color="#121212" roughness={0.4} metalness={0.6} />
                </RoundedBox>

                {/* The Screen (Video Texture) */}
                <mesh 
                    position={[0, 0, settings.extrusion / 2 + 0.001]}
                    onPointerDown={handlePointerDown}
                    onPointerOver={() => document.body.style.cursor = settings.zoom.picking ? 'crosshair' : 'default'}
                    onPointerOut={() => document.body.style.cursor = 'default'}
                >
                    <planeGeometry args={[width - 0.1, height - 0.1]} />
                    <meshBasicMaterial map={texture} toneMapped={false} />
                </mesh>

                {/* Back Plate */}
                <mesh position={[0, 0, -(settings.extrusion / 2 + 0.001)]} rotation={[0, Math.PI, 0]}>
                    <planeGeometry args={[width - 0.1, height - 0.1]} />
                    <meshStandardMaterial color="#222" roughness={0.2} metalness={0.8} />
                </mesh>
            </group>
        </Float>

        {/* Floor Reflection */}
        {settings.background !== 'transparent' && (
            <group position={[0, -height/1.5, 0]}>
                 <MeshReflectorMaterial
                    blur={[300, 100]}
                    resolution={1024}
                    mixBlur={1}
                    mixStrength={settings.reflectionOpacity * 2}
                    roughness={1}
                    depthScale={1.2}
                    minDepthThreshold={0.4}
                    maxDepthThreshold={1.4}
                    color="#f0f0f0"
                    metalness={0.1}
                    mirror={0} 
                />
                 <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]}>
                    <planeGeometry args={[50, 50]} />
                    <MeshReflectorMaterial
                        blur={[300, 100]}
                        resolution={1024}
                        mixBlur={1}
                        mixStrength={settings.reflectionOpacity * 1.5}
                        roughness={0.8}
                        depthScale={1.2}
                        minDepthThreshold={0.4}
                        maxDepthThreshold={1.4}
                        color="#f5f5f5"
                        metalness={0.1}
                        mirror={1} 
                    />
                </mesh>
            </group>
        )}
    </group>
  );
};

const BackgroundEnv = ({ type }: { type: BackgroundType }) => {
  if (type === 'transparent') return null;

  return (
    <>
      {type === 'studio' && (
        <>
            <Environment preset="city" />
            <color attach="background" args={['#F3F4F6']} />
            <Grid infiniteGrid fadeDistance={50} sectionColor="#000000" cellColor="#cccccc" position={[0, -5, 0]} />
        </>
      )}
      {type === 'mesh' && (
        <>
            <Environment preset="night" />
            <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />
            <Sparkles count={50} scale={10} size={4} speed={0.4} opacity={0.5} color="#00F0FF" />
            <color attach="background" args={['#111']} />
        </>
      )}
      <ambientLight intensity={0.6} />
    </>
  );
};

// Advanced Camera Controller that handles Orbit AND Zoom
const SmartCameraRig = ({ 
    settings, 
    videoSrc 
}: { 
    settings: SceneSettings; 
    videoSrc: string 
}) => {
    const { camera } = useThree();
    const controlsRef = useRef<any>(null);
    
    // Noise state for shake
    const shakeTime = useRef(0);

    // Calculate dimensions again for target positioning (simplified approximation)
    // In a real app we'd share this via Context or Store
    const width = 4;
    const height = width / (16/9); // Approximate, assuming 16:9 for camera calcs

    useFrame((state, delta) => {
        // Handle Shake
        let shakeX = 0;
        let shakeY = 0;
        if (settings.zoom.shake > 0) {
            shakeTime.current += delta * 10;
            const intensity = settings.zoom.shake * 0.2;
            shakeX = Math.sin(shakeTime.current) * intensity;
            shakeY = Math.cos(shakeTime.current * 1.5) * intensity;
        }

        if (settings.zoom.active) {
            // ZOOM MODE
            // 1. Disable Orbit Controls interactions
            if (controlsRef.current) controlsRef.current.enabled = false;

            // 2. Calculate World Target Position based on UV
            // We need to account for the Mesh's current rotation/scale
            // This is complex math, but we can approximate for the camera target
            
            // Simplified: The camera zooms into the "Screen Plane" 
            // We want to move the camera closer to the object.
            
            // Calculate picking point relative to center
            const relX = (settings.zoom.target.x - 0.5) * width;
            const relY = (settings.zoom.target.y - 0.5) * -height; // Y is inverted in 3D

            // Target camera position: In front of the point, closer based on intensity
            // Base distance is 8. Intensity 2 = dist 4. Intensity 4 = dist 2.
            const targetDist = 8 / settings.zoom.intensity;
            
            // We simply want to look at the point (relX, relY, 0)
            // And position camera at (relX, relY, targetDist)
            // But we must respect the scene rotation? 
            // Ideally, we move the camera in local space of the mesh, but mesh rotates.
            
            // For this specific 'TiltStudio' vibe, we will zoom towards the point 
            // while maintaining the current Perspective angle roughly.
            
            const currentPos = camera.position;
            const targetPos = new THREE.Vector3(relX, relY, targetDist);
            
            // Apply shake to target
            targetPos.x += shakeX;
            targetPos.y += shakeY;

            // Smoothly interpolate Camera Position
            camera.position.lerp(targetPos, 0.05);
            
            // Smoothly look at the target point on the mesh
            // We need a dummy vector to lerp the "lookAt" target
            // Ideally OrbitControls.target handles this, but we disabled it.
            // We can manually set camera quaternion or just let it be if simple.
            
            // Better: Update OrbitControls target property to smoothly pan
            if (controlsRef.current) {
                const currentTarget = controlsRef.current.target;
                const desiredTarget = new THREE.Vector3(relX + shakeX, relY + shakeY, 0);
                currentTarget.lerp(desiredTarget, 0.05);
                camera.lookAt(currentTarget);
            }

        } else {
            // ORBIT MODE (Default)
            if (controlsRef.current) {
                controlsRef.current.enabled = true;
                // Reset target to center slowly
                controlsRef.current.target.lerp(new THREE.Vector3(0, 0, 0), 0.05);
            }
        }
    });

    return (
        <OrbitControls 
            ref={controlsRef}
            makeDefault 
            autoRotate={settings.orbitPreview && !settings.zoom.active}
            autoRotateSpeed={2}
            enablePan={false}
            minPolarAngle={Math.PI / 4}
            maxPolarAngle={Math.PI / 2}
        />
    );
}

const SceneCanvas: React.FC<SceneCanvasProps> = ({ videoSrc, settings, updateSettings }) => {
  const handlePick = (uv: THREE.Vector2) => {
      // Update target and disable picking mode
      updateSettings({ 
          zoom: { 
              ...settings.zoom, 
              target: { x: uv.x, y: uv.y },
              picking: false // Auto-exit picking mode after selection
          } 
      });
  };

  return (
    <div className="w-full h-full relative bg-transparent group">
        {/* Picking Overlay Hint */}
        {settings.zoom.picking && (
            <div className="absolute top-4 left-1/2 -translate-x-1/2 z-50 bg-red-500 text-white px-4 py-2 font-bold uppercase tracking-wider text-sm shadow-neo border-2 border-white animate-pulse pointer-events-none">
                Click anywhere on video to set focus
            </div>
        )}

        {/* Background Color fallback */}
        {settings.background === 'studio' && <div className="absolute inset-0 bg-gray-100 -z-10" />}
        {settings.background === 'mesh' && <div className="absolute inset-0 bg-black -z-10" />}

        <Canvas 
            shadows 
            camera={{ position: [0, 0, 8], fov: 45 }}
            gl={{ preserveDrawingBuffer: true, alpha: settings.background === 'transparent' }}
            dpr={[1, 2]} 
        >
            <Suspense fallback={null}>
                <BackgroundEnv type={settings.background} />
                
                {/* Main Lights */}
                <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} intensity={1} castShadow />
                <pointLight position={[-10, -10, -10]} intensity={settings.ambientLightIntensity} />
                
                <VideoMesh 
                    videoSrc={videoSrc} 
                    settings={settings} 
                    onPick={handlePick}
                />
                
                <SmartCameraRig settings={settings} videoSrc={videoSrc} />
                
                {/* Contact shadows for grounding */}
                {settings.background !== 'transparent' && (
                   <ContactShadows position={[0, -2.5, 0]} opacity={0.4} scale={20} blur={2} far={4.5} />
                )}
            </Suspense>
        </Canvas>
    </div>
  );
};

export default SceneCanvas;