import React, { useRef, useState } from 'react';
import { Upload, Film } from 'lucide-react';

interface DropZoneProps {
  onFileSelect: (file: File) => void;
}

const DropZone: React.FC<DropZoneProps> = ({ onFileSelect }) => {
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      if (file.type.startsWith('video/')) {
        onFileSelect(file);
      } else {
        alert("Please upload a video file.");
      }
    }
  };

  const handleClick = () => {
    fileInputRef.current?.click();
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onFileSelect(e.target.files[0]);
    }
  };

  return (
    <div 
      className={`
        w-full h-full flex flex-col items-center justify-center 
        transition-all duration-200
        border-4 border-dashed rounded-none
        cursor-pointer
        relative z-30
        ${isDragging 
          ? 'border-neo-black dark:border-white bg-pastel-blue dark:bg-neo-gray scale-[0.98]' 
          : 'border-neo-black dark:border-white bg-white dark:bg-neo-darkgray hover:bg-pastel-yellow dark:hover:bg-neo-gray'
        }
      `}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      onClick={handleClick}
    >
      <input 
        type="file" 
        ref={fileInputRef} 
        onChange={handleInputChange} 
        className="hidden" 
        accept="video/*"
      />
      
      <div className={`p-6 border-2 border-neo-black dark:border-white bg-pastel-pink dark:bg-pastel-pink shadow-neo dark:shadow-neo-white mb-6 transition-transform duration-300 ${isDragging ? 'rotate-12 scale-110' : '-rotate-6'}`}>
        <Upload className="w-10 h-10 text-neo-black" strokeWidth={2.5} />
      </div>

      <h3 className="text-3xl font-black text-neo-black dark:text-white mb-2 font-sans uppercase">
        Drop Video
      </h3>
      <p className="text-neo-black font-mono text-sm bg-pastel-green px-2 py-1 border-2 border-neo-black dark:border-white dark:bg-pastel-blue">
        or click to browse
      </p>

      <div className="mt-8 flex gap-3">
        <div className="flex items-center gap-2 px-3 py-1.5 bg-neo-black dark:bg-white text-white dark:text-neo-black text-xs font-bold font-mono">
           <Film size={12} /> 1080P READY
        </div>
      </div>
    </div>
  );
};

export default DropZone;