import React from 'react';
import { SceneSettings, Preset, BackgroundType, PresetName } from '../../types';
import { PRESETS } from '../../constants';
import { 
  Maximize, 
  Layers, 
  Aperture, 
  Sun, 
  Grid, 
  Box, 
  Ghost, 
  Play, 
  LayoutTemplate,
  Monitor,
  Scan,
  Zap,
  Crosshair,
  Vibrate
} from 'lucide-react';

interface SidebarProps {
  settings: SceneSettings;
  updateSettings: (newSettings: Partial<SceneSettings>) => void;
  applyPreset: (presetId: PresetName) => void;
}

const ControlGroup = ({ title, icon: Icon, children }: { title: string, icon: any, children: React.ReactNode }) => (
  <div className="mb-10 p-4 border-2 border-neo-black dark:border-white bg-white dark:bg-neo-gray shadow-neo dark:shadow-neo-white transition-colors">
    <div className="flex items-center gap-2 mb-4 text-neo-black dark:text-white border-b-2 border-neo-black dark:border-white pb-2">
      <Icon size={20} strokeWidth={2.5} />
      <span className="text-sm font-black uppercase tracking-wider">{title}</span>
    </div>
    <div className="space-y-5">
      {children}
    </div>
  </div>
);

const Slider = ({ label, value, min, max, step, onChange }: { label: string, value: number, min: number, max: number, step: number, onChange: (val: number) => void }) => {
  const safeValue = isNaN(value) ? min : value;
  const percentage = Math.min(100, Math.max(0, ((safeValue - min) / (max - min)) * 100));
  
  return (
    <div className="group">
      <div className="flex justify-between mb-2">
        <label className="text-sm font-bold text-neo-black dark:text-white">{label}</label>
        <span className="text-xs font-mono bg-neo-black dark:bg-white text-white dark:text-neo-black px-2 py-0.5 rounded-sm font-bold">
            {safeValue.toFixed(2)}
        </span>
      </div>
      <div className="relative h-6 flex items-center">
          <input 
          type="range" 
          min={min} 
          max={max} 
          step={step} 
          value={safeValue} 
          onChange={(e) => {
             const v = parseFloat(e.target.value);
             if (!isNaN(v)) {
                 onChange(v);
             }
          }}
          className="w-full absolute z-20 opacity-0 cursor-pointer h-full inset-0 m-0 p-0 appearance-none"
          />
          {/* Custom Track */}
          <div className="w-full h-3 bg-white dark:bg-neo-black border-2 border-neo-black dark:border-white relative overflow-hidden pointer-events-none">
               {/* Fill */}
               <div 
                  className="h-full bg-pastel-green dark:bg-pastel-blue border-r-2 border-neo-black dark:border-white" 
                  style={{ width: `${percentage}%` }}
               />
          </div>
          {/* Custom Thumb (Visual Only) */}
          <div 
              className="absolute h-6 w-3 bg-neo-black dark:bg-white pointer-events-none transition-all z-10 border-2 border-transparent"
              style={{ left: `calc(${percentage}% - 6px)` }}
          />
      </div>
    </div>
  );
};

const Toggle = ({ label, checked, onChange }: { label: string, checked: boolean, onChange: (val: boolean) => void }) => (
  <div className="flex items-center justify-between py-1">
    <span className="text-sm font-bold text-neo-black dark:text-white">{label}</span>
    <button 
      onClick={() => onChange(!checked)}
      className={`relative w-12 h-6 border-2 border-neo-black dark:border-white transition-colors duration-200 ease-in-out ${checked ? 'bg-pastel-pink dark:bg-pastel-pink' : 'bg-gray-200 dark:bg-neo-black'}`}
    >
      <span className={`absolute top-0 left-0 w-5 h-5 bg-neo-black dark:bg-white border-2 border-neo-black dark:border-white transition-transform duration-200 ease-in-out ${checked ? 'translate-x-6 bg-white dark:bg-neo-black' : 'translate-x-0'}`} />
    </button>
  </div>
);

const Sidebar: React.FC<SidebarProps> = ({ settings, updateSettings, applyPreset }) => {

  const updateZoom = (changes: Partial<typeof settings.zoom>) => {
      updateSettings({ zoom: { ...settings.zoom, ...changes } });
  };

  return (
    <div className="h-full w-96 bg-pastel-yellow dark:bg-neo-black border-l-2 border-neo-black dark:border-white p-6 overflow-y-auto transition-colors duration-300">
      
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-2xl font-black text-neo-black dark:text-white uppercase italic">Controls</h2>
        <div className="w-4 h-4 bg-pastel-green dark:bg-pastel-blue border-2 border-neo-black dark:border-white shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] dark:shadow-[2px_2px_0px_0px_rgba(255,255,255,1)] animate-bounce"></div>
      </div>

      {/* Magic Presets */}
      <ControlGroup title="Vibe Gallery" icon={LayoutTemplate}>
        <div className="grid grid-cols-2 gap-3">
            {PRESETS.map((preset) => (
                <button
                    key={preset.id}
                    onClick={() => applyPreset(preset.id)}
                    className="px-3 py-3 text-xs font-bold text-left bg-neo-white dark:bg-neo-black text-neo-black dark:text-white border-2 border-neo-black dark:border-white shadow-neo-sm dark:shadow-neo-sm-white hover:translate-x-[1px] hover:translate-y-[1px] hover:shadow-none hover:bg-pastel-blue dark:hover:bg-pastel-blue dark:hover:text-neo-black transition-all active:bg-pastel-pink"
                >
                    {preset.name}
                </button>
            ))}
        </div>
      </ControlGroup>

      {/* New ZOOM & FOCUS Panel */}
      <ControlGroup title="Smart Zoom" icon={Scan}>
          {/* Target Picker */}
          <div className="flex gap-2">
            <button
                onClick={() => updateZoom({ picking: !settings.zoom.picking, active: false })}
                className={`flex-1 flex items-center justify-center gap-2 py-3 text-xs font-black uppercase border-2 border-neo-black dark:border-white transition-all ${settings.zoom.picking ? 'bg-red-500 text-white animate-pulse' : 'bg-white dark:bg-neo-black text-neo-black dark:text-white hover:bg-gray-100'}`}
            >
                <Crosshair size={16} />
                {settings.zoom.picking ? 'Click Video...' : 'Set Target'}
            </button>

            {/* Trigger Button */}
            <button
                onClick={() => updateZoom({ active: !settings.zoom.active, picking: false })}
                className={`flex-1 flex items-center justify-center gap-2 py-3 text-xs font-black uppercase border-2 border-neo-black dark:border-white transition-all ${settings.zoom.active ? 'bg-pastel-green text-neo-black shadow-none translate-x-[2px] translate-y-[2px]' : 'bg-neo-black text-white shadow-neo-sm hover:translate-x-[1px] hover:translate-y-[1px] hover:shadow-none'}`}
            >
                <Zap size={16} fill={settings.zoom.active ? "currentColor" : "none"} />
                {settings.zoom.active ? 'Active' : 'Trigger Zoom'}
            </button>
          </div>

          <div className="h-px bg-neo-black dark:bg-white opacity-20 my-2"></div>

          <Slider 
            label="Zoom Power" 
            value={settings.zoom.intensity} 
            min={1.2} max={5} step={0.1} 
            onChange={(v) => updateZoom({ intensity: v })} 
          />
          <Slider 
            label="Camera Shake" 
            value={settings.zoom.shake} 
            min={0} max={1} step={0.1} 
            onChange={(v) => updateZoom({ shake: v })} 
          />

          <div className="flex items-center gap-2 text-[10px] font-mono text-gray-500 bg-gray-100 dark:bg-gray-800 p-2 border border-neo-black dark:border-white">
             <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
             <span>Target: X {settings.zoom.target.x.toFixed(2)} / Y {settings.zoom.target.y.toFixed(2)}</span>
          </div>
      </ControlGroup>

      {/* Perspective Tilt */}
      <ControlGroup title="Perspective" icon={Maximize}>
        <Slider 
            label="Rotate X (Tilt)" 
            value={settings.rotation.x} 
            min={-1.5} max={1.5} step={0.01} 
            onChange={(v) => updateSettings({ rotation: { ...settings.rotation, x: v } })} 
        />
        <Slider 
            label="Rotate Y (Pan)" 
            value={settings.rotation.y} 
            min={-1.5} max={1.5} step={0.01} 
            onChange={(v) => updateSettings({ rotation: { ...settings.rotation, y: v } })} 
        />
        <Slider 
            label="Scale" 
            value={settings.scale} 
            min={0.5} max={2} step={0.1} 
            onChange={(v) => updateSettings({ scale: v })} 
        />
      </ControlGroup>

      {/* Depth & Form */}
      <ControlGroup title="Dimensions" icon={Box}>
        <Slider 
            label="Extrusion Depth" 
            value={settings.extrusion} 
            min={0} max={2} step={0.1} 
            onChange={(v) => updateSettings({ extrusion: v })} 
        />
        <Slider 
            label="Corner Radius" 
            value={settings.borderRadius} 
            min={0} max={0.5} step={0.01} 
            onChange={(v) => updateSettings({ borderRadius: v })} 
        />
      </ControlGroup>

      {/* Environment */}
      <ControlGroup title="Environment" icon={Grid}>
        <div className="flex border-2 border-neo-black dark:border-white bg-white dark:bg-neo-black p-1 mb-4 gap-1">
            {(['studio', 'mesh', 'transparent'] as BackgroundType[]).map((bg) => (
                <button
                    key={bg}
                    onClick={() => updateSettings({ background: bg })}
                    className={`flex-1 py-1.5 text-xs font-bold uppercase transition-all border-2 ${settings.background === bg ? 'bg-pastel-yellow dark:bg-white text-neo-black border-neo-black dark:border-white shadow-neo-sm' : 'border-transparent text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'}`}
                >
                    {bg}
                </button>
            ))}
        </div>
        <Slider 
            label="Floor Reflection" 
            value={settings.reflectionOpacity} 
            min={0} max={1} step={0.1} 
            onChange={(v) => updateSettings({ reflectionOpacity: v })} 
        />
      </ControlGroup>

      {/* Effects */}
      <ControlGroup title="Post FX" icon={Aperture}>
        <Toggle 
            label="Motion Blur (Fake)" 
            checked={settings.motionBlur} 
            onChange={(v) => updateSettings({ motionBlur: v })} 
        />
        <p className="text-[10px] font-bold bg-pastel-blue/30 dark:bg-pastel-blue/10 p-2 border-2 border-dashed border-neo-black dark:border-gray-500 text-neo-black dark:text-gray-300 mb-4">Adds float movement & subtle blur</p>

        <Toggle 
            label="Backlight Glow" 
            checked={settings.glow} 
            onChange={(v) => updateSettings({ glow: v })} 
        />
      </ControlGroup>
      
      {/* Preview */}
       <div className="p-4 border-2 border-neo-black dark:border-white bg-pastel-pink dark:bg-pastel-pink shadow-neo dark:shadow-neo-white">
        <button
            onClick={() => updateSettings({ orbitPreview: !settings.orbitPreview })}
            className={`w-full flex items-center justify-center gap-2 py-3 font-black uppercase text-sm border-2 border-neo-black transition-all ${
                settings.orbitPreview 
                ? 'bg-neo-black text-white shadow-none translate-x-[4px] translate-y-[4px]' 
                : 'bg-white text-neo-black shadow-neo hover:translate-x-[2px] hover:translate-y-[2px] hover:shadow-neo-sm'
            }`}
        >
           {settings.orbitPreview ? <Play size={16} fill="currentColor" /> : <Play size={16} />} 
           {settings.orbitPreview ? 'Orbiting...' : 'Orbit Preview'}
        </button>
      </div>
      <div className="h-20"></div> {/* Spacer */}
    </div>
  );
};

export default Sidebar;