import React, { useState, useEffect } from 'react';
import { Play, Pause, Square, Circle, ChevronUp } from 'lucide-react';

const Timeline: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [isRecording, setIsRecording] = useState(false);

  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    if (isPlaying) {
      interval = setInterval(() => {
        setProgress((prev) => (prev >= 100 ? 0 : prev + 0.5));
      }, 50);
    }
    return () => clearInterval(interval);
  }, [isPlaying]);

  const toggleRecord = () => {
    setIsRecording(!isRecording);
    if (!isRecording) setIsPlaying(true);
    else setIsPlaying(false);
  }

  return (
    <div className="w-full h-52 bg-white dark:bg-neo-gray border-t-2 border-neo-black dark:border-white flex flex-col transition-colors">
      {/* Toolbar */}
      <div className="h-12 border-b-2 border-neo-black dark:border-white bg-pastel-yellow dark:bg-neo-black flex items-center px-4 justify-between transition-colors">
         <div className="flex items-center gap-4">
             <button 
                onClick={() => setIsPlaying(!isPlaying)}
                className="w-8 h-8 flex items-center justify-center bg-white dark:bg-neo-gray border-2 border-neo-black dark:border-white shadow-neo-sm dark:shadow-neo-sm-white hover:translate-x-[2px] hover:translate-y-[2px] hover:shadow-none transition-all active:bg-pastel-blue"
             >
                 {isPlaying ? <Pause size={16} fill="currentColor" className="text-neo-black dark:text-white" /> : <Play size={16} fill="currentColor" className="text-neo-black dark:text-white" />}
             </button>
             <button 
                onClick={toggleRecord}
                className={`flex items-center gap-2 px-3 py-1 text-xs font-black uppercase border-2 border-neo-black dark:border-white shadow-neo-sm dark:shadow-neo-sm-white transition-all hover:translate-y-[1px] hover:shadow-none ${isRecording ? 'bg-red-500 text-white' : 'bg-white dark:bg-neo-gray text-neo-black dark:text-white hover:bg-red-100 dark:hover:bg-red-900'}`}
             >
                 <Circle size={10} fill={isRecording ? "currentColor" : "none"} />
                 {isRecording ? "REC" : "REC"}
             </button>
             <div className="text-sm font-black font-mono text-neo-black dark:text-white bg-white dark:bg-neo-gray border-2 border-neo-black dark:border-white px-2 py-0.5">
                00:00:{Math.floor((progress / 100) * 10).toString().padStart(2, '0')}
             </div>
         </div>
         
         <div className="flex items-center gap-2">
            <span className="text-xs uppercase bg-neo-black dark:bg-white text-white dark:text-neo-black px-2 py-1 font-bold tracking-widest">Keyframe Mode</span>
         </div>
      </div>

      {/* Tracks */}
      <div className="flex-1 p-4 overflow-hidden relative bg-[radial-gradient(#000000_1px,transparent_1px)] dark:bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:20px_20px] opacity-100">
        {/* Playhead */}
        <div 
            className="absolute top-0 bottom-0 w-1 bg-red-500 z-20 pointer-events-none"
            style={{ left: `${progress}%` }}
        >
            <div className="w-4 h-4 bg-red-500 border-2 border-neo-black dark:border-white -ml-[6px] rotate-45 transform mt-0" />
        </div>

        {/* Track Rows */}
        <div className="space-y-3 mt-2">
            <TrackRow label="Rotation X" active={progress > 10 && progress < 40} color="bg-pastel-blue" />
            <TrackRow label="Rotation Y" active={progress > 30 && progress < 60} color="bg-pastel-green" />
            <TrackRow label="Depth" active={progress > 50 && progress < 80} color="bg-pastel-pink" />
        </div>
      </div>
    </div>
  );
};

const TrackRow = ({ label, active, color }: { label: string, active: boolean, color: string }) => (
    <div className="h-8 flex items-center">
        <div className="w-28 text-xs font-bold uppercase text-neo-black dark:text-white shrink-0 bg-white dark:bg-neo-black border-2 border-neo-black dark:border-white px-2 py-1 mr-2">{label}</div>
        <div className="flex-1 h-8 bg-white dark:bg-neo-black border-2 border-neo-black dark:border-white relative group cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-900 transition-colors">
             {/* Mock Keyframes */}
             <div className={`absolute top-1/2 -translate-y-1/2 left-[10%] w-3 h-3 border-2 border-neo-black dark:border-white rotate-45 ${active ? 'bg-neo-black dark:bg-white' : 'bg-white dark:bg-neo-black'}`} />
             <div className="absolute top-1/2 -translate-y-1/2 left-[40%] w-3 h-3 border-2 border-neo-black dark:border-white rotate-45 bg-white dark:bg-neo-black" />
             <div className="absolute top-1/2 -translate-y-1/2 left-[80%] w-3 h-3 border-2 border-neo-black dark:border-white rotate-45 bg-white dark:bg-neo-black" />
             
             {/* Active Region */}
             {active && (
                 <div className={`absolute top-1/2 -translate-y-1/2 left-[10%] w-[30%] h-2 border-y-2 border-neo-black dark:border-white ${color} opacity-100 -z-0`} />
             )}
             
             {/* Connection Line Base */}
             <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-gray-200 dark:bg-gray-700 -z-10" />
        </div>
    </div>
);

export default Timeline;