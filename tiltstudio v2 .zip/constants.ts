
import { Preset, SceneSettings } from './types';

export const DEFAULT_SETTINGS: SceneSettings = {
  rotation: { x: 0, y: -0.2, z: 0 },
  scale: 1,
  extrusion: 0.2,
  borderRadius: 0.1,
  reflectionOpacity: 0.5,
  background: 'studio',
  motionBlur: false,
  glow: false,
  ambientLightIntensity: 0.5,
  orbitPreview: false,
  zoom: {
    active: false,
    picking: false,
    target: { x: 0.5, y: 0.5 }, // Center
    intensity: 2.5,
    duration: 1.5,
    shake: 0,
    type: 'cinematic',
  },
};

export const PRESETS: Preset[] = [
  {
    name: 'SaaS Launch',
    id: 'saas-launch',
    settings: {
      rotation: { x: 0.1, y: -0.4, z: 0.05 },
      scale: 1.1,
      extrusion: 0.3,
      glow: true,
      background: 'studio',
      orbitPreview: true,
      zoom: { ...DEFAULT_SETTINGS.zoom, intensity: 1.5, shake: 0.1 }
    },
  },
  {
    name: 'Mobile Scroll',
    id: 'mobile-scroll',
    settings: {
      rotation: { x: 0, y: 0, z: 0 },
      scale: 0.8,
      borderRadius: 0.3,
      extrusion: 0.5, // Thicker phone-like look
      reflectionOpacity: 0.8,
      motionBlur: true,
    },
  },
  {
    name: 'Dark Mode Glow',
    id: 'dark-mode-glow',
    settings: {
      rotation: { x: -0.1, y: 0.3, z: -0.05 },
      glow: true,
      background: 'mesh',
      ambientLightIntensity: 0.2, // Darker ambient
      extrusion: 0.1,
    },
  },
];
