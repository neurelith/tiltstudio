
export type BackgroundType = 'studio' | 'mesh' | 'transparent';

export interface ZoomSettings {
  active: boolean; // Is zoom currently engaged?
  picking: boolean; // Is user selecting a point?
  target: { x: number; y: number }; // UV Coordinates (0-1)
  intensity: number; // 1 to 5 (Zoom level)
  duration: number; // Animation speed
  shake: number; // 0 to 1
  type: 'static' | 'cinematic';
}

export interface SceneSettings {
  rotation: { x: number; y: number; z: number };
  scale: number;
  extrusion: number; // Depth/Thickness
  borderRadius: number;
  reflectionOpacity: number;
  background: BackgroundType;
  motionBlur: boolean;
  glow: boolean; // Backlight glow
  ambientLightIntensity: number;
  orbitPreview: boolean; // Auto-rotate camera
  zoom: ZoomSettings;
}

export interface VideoState {
  src: string | null;
  aspectRatio: number;
  isPlaying: boolean;
  duration: number;
  currentTime: number;
}

export type PresetName = 'default' | 'saas-launch' | 'mobile-scroll' | 'dark-mode-glow';

export interface Preset {
  name: string;
  id: PresetName;
  settings: Partial<SceneSettings>;
}
